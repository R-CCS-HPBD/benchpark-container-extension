# 既存試験の移行理由

元の332ケースを削除せず維持する。初回327PASS/5FAILのログはresults/runtime-baselineとruntime-01へ保存。

|ファイル|変更|保持した検査|
|---|---|---|
|test_contract.py|Dockerが対応対象となったため拒否対象をunregistered-runtimeへ変更|未知runtimeはValidationError、他の不正設定条件は変更なし。3runtimeのpositive testを追加|
|test_storage_runtime.py|Apptainer固定monkeypatchからregistry内backendへ移動。AdapterDoubleにbackend基本状態を初期化|全assertを同一ASTで保持。activation、partial environment、benchmark failure phaseの意味は不変|
|test_reference_equivalence.py|承認したruntime.py/contracts.py/preparation.pyの指定関数だけbyte比較から除外|全未変更ファイルは引き続きbyte一致。承認ファイルの未変更関数・class・constantをAST一致で検査。旧テスト関数名の全維持、fixed snapshot差分検査を維持|

追加のsource guardでCore/integration/resolver/artifact/CER不変、既存assert保全、凍結確認表、runtime追加非侵襲性を検査する。Dockerの正常/失敗/identity/cleanupはtest doubleであり実機PASSではない。
