# 3-runtime追加確認リスト（実装前に固定）

基準: 添付v0.6.1、9/16メモ、今回の実装指示。既存C01-C26は原本のまま全件併用。
PASS_LOCALは静的・単体・test-double結合の範囲。実機未実行はPENDING-EXTERNAL。

|ID|項目|条件|
|---|---|---|
|R01|runtime選択|Systemのruntimeをregistryで解決し、不明runtime/不正設定は停止。Experiment workflowは不変。|
|R02|最小共通契約|ImageRef/ExecutionRequest/RuntimeBackendを定義しCLI差をbackendへ隔離。|
|R03|Apptainer非回帰|既存SIF/pinned OCI・bind・宣言tools・environment・GPU・CER経路を維持。|
|R04|Singularity分離|独立backend、実executable/version、SINGULARITY_*の環境制御とcacheを区別。|
|R05|Docker image固定|digestを必須にしRepoDigests/Id/platformを検証、実行は解決したimage IDで固定。SIFを拒否。|
|R06|共通mount|scratch/read-only inputs/private outputs、workdir、空白pathを保持し不正encodingを拒否。|
|R07|environment/entrypoint|明示environmentとallocationを処理。Dockerのimage ENTRYPOINT/CMDで要求commandが変わらない。|
|R08|CUDA|3 runtimeのGPU CLIを検査。Docker選択GPUのcontainer内ordinalを扱い、allocationの黙った拡大を避ける。|
|R09|ROCm|SIF --rocm、Docker kfd/render devices/groupの設定と不正値/曖昧allocationを検査。|
|R10|依存構築|Base Python/pip/Bashによる同一requirements/setup処理。lifecycle接続以外の既存構築関数は不変。|
|R11|正常/非zero|成功/非zeroを区別しstdout/FoM、stderr、exit code、CER failure_phaseを保持。|
|R12|timeout/中断|benchmarkとpreparation両方のtimeout/中断でprocess終了、runtime固有cleanup、失敗CERを保持。|
|R13|Docker後始末|所有labelとcontainer IDを確認し当該containerのみ削除。cleanup失敗を成功にしない。|
|R14|観測の正確性|runtime名/version/executable、SIF hashまたはOCI digest/Id、実command/cleanupを保存。|
|R15|CER互換性|schema v2と既存SIF観測キー/CLI/hash検証/再試行非上書きを維持。|
|R16|第4backend拡張|新backend+registry+testsのみでnode workerを含め利用可能。共通実行/Core/既存backend/CERは変更不要。|
|R17|配布整合|全backendの自動bundle、stdlib-only worker、wheel/source/versionの整合とclean installを検証。|
|R18|機能境界|Core/integration/resolver/artifacts/CER recordingを入力ZIPから変更しない。|
|R19|既存試験保全|既存assertを弱めない。凍結byte比較のruntime拡張例外は理由・差分・代替検査を保存。|
|R20|全件再レビュー|修正roundごとC01-C26とR01-R24を先頭から再判定しsource hashとログを保存。|
|R21|実機CPU/mount/setup|3 runtime各々の実環境CPU smoke、mount、requirements/setup、CER完走は実ログを要求。|
|R22|実機GPU|3 runtime CUDA/ROCmの実GPU確認は実ログを要求しCLI検査とは分ける。|
|R23|実Benchpark/Spack|新成果物でstock Spack/導入後Spack/+containerの実workflowを確認。過去PASSを流用しない。|
|R24|リリース判定|実機未実行をPENDING-EXTERNALと記しv1.0正式releaseの合格条件と開発版完了を区別。|
