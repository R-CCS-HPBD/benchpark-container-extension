# 実装・検証で検出した事項

本書は結果の経緯。成功時だけでなく失敗ログも残す。自己レビューであり、独立第三者レビューや実機合格の証明ではない。

|段階|検出事項|処置・根拠|
|---|---|---|
|入力baseline|既存332件PASS|`results/runtime-baseline/pytest.log`|
|初回runtime移設|327PASS/5FAIL。旧Docker拒否条件、旧monkeypatch接続、runtime全体byte固定|旧試験の削除・assert弱体化をせず移行。`TEST_MIGRATION.ja.md`、runtime-01全件レビュー|
|Docker lifecycle追加試験|途中観測でatomic_jsonの非上書き契約と衝突|番号付きimmutable eventへ変更。最終summaryをclose時に1回だけ発行。非上書き・再close試験を追加|
|異常終了検証|benchmarkが0でもcleanup失敗なら実験成功にしてはいけない|非zero return/EXECUTION_ERRORとcleanup失敗証跡を検査。timeout/割込みの一次エラーは保持|
|所有権・再試行試験|daemon doubleが同一container IDを使い回していた|doubleを呼出ごとの固有IDへ修正。実daemonを使用した証拠にはしない|
|process timeout試験|0.15秒ではPython起動前に中断し得る|1.5秒に変更し、stdout/stderr/cleanupのassertを維持|
|runtime acceptance tool試験|fixture digestが既存のplaceholder拒否に該当、試験側のplan/status参照名が旧形式|拒否規則を緩めず、test-only固定値と期待キーを修正。runtime欠落はPREPARATION_FAILED、reportはFAILED|
|全件試験実行|外側実行ツールのtimeout/SIGTERMで1件が中断扱い、465PASS/1FAIL|同一ソースを独立sessionで再実行し466PASS。`pytest-pre-review.log`と`pytest-isolated.log`の両方を保持|
|最終受入|native runtime/GPU/Benchparkがこの環境に無い|C23/R21/R22/R23は保留。過去Apptainer実績・daemon double・CLI検査を実機PASSとして使わない|

修正は作業roundにまとめ、全項目レビューをround境界でC01からR24まで再実施する。round内の各編集直後は対象試験でフィードバックし、対象試験だけを最終合格根拠にしない。初期FAILと最終レビューのsource manifest、notes hash、全試験ログを残す。全未知バグが無いという主張ではない。
