# 実機受入runbook — 1.0.0.dev1

## 0. 現状と判定基準

本ファイルは**実行手順**であり、実行済みログではない。実装環境ではApptainer/Singularity/Docker/Benchpark/Ramble/GPUが利用できず、C23・R21・R22・R23はPENDING-EXTERNAL。過去Apptainer成功記述は今回の配布物の受入へ流用しない。

次を分けて記録する。

|区分|必要な証拠|この版のローカル試験で代替できるか|
|---|---|---|
|backend contract|registry、CLI、固定image/cleanup、異常系|ローカル試験で確認する範囲|
|native runtime CPU|3 runtime各々のimage起動、RO input、RW result、pwd、setup、CER|不可|
|native追加依存|Baseに無い固定packageを実際に追加しresolved_additionsで確認|空requirementsの成功では不可|
|GPU|3 runtimeでCUDA/ROCmの該当機を使い、GPU上の実計算・割当数確認|`--nv`/`--gpus`生成では不可|
|Benchpark/Spack|stock→導入後Spack→各runtimeの+containerの実workflow/分析|patch適用、CLI fixture、単体workerでは不可|

## 1. 既存環境と旧実験を保護する

既存workspaceは再利用しない。System/Experiment/workspaceの新規ディレクトリをruntimeごとに用意する。現在のBenchpark git commit/branch/dirty状態、Extension artifact SHA-256、host driver、選択runtimeのversionと実行ファイル、image digest/SIF hashを記録する。

Core patchはv0.6.1から変更していない。すでに正しく適用された環境へ重複applyしない。未適用環境はREADMEのgenerate→review→`git apply --check`→明示applyに従う。pip install自体はCoreを書き換えない。今回の作業ではユーザーの計算機へinstall/applyしていない。

## 2. ベースイメージとrequirementsを準備する

各image自身にPython、pip、Bashを用意する。GPUの場合は対応framework（以下のprobeではPyTorch）を含める。imageは運用者が確定した本物のimmutable digestか、実在するSIFとし、タグ・ダミーdigestを使用しない。

requirementsはBaseと競合せず、追加packageとtransitive dependencyを全て固定した**自己完結のtext**を渡す。`--require-additions`を使い、Baseに無い追加packageの導入を必須にする。相対includeやlocal wheelを使用する本番実験は通常のExperiment資材として管理する。下記probeはその相対資材一式を自動収集しない。

## 3. 単体runtimeの実受入

運用者が変数を設定してから実行する。以下はplaceholderを実行しないよう必須値を検査する。

```bash
set -euo pipefail
: "${BPCE_ROOT:?展開したこの版のrepo}"
: "${RUNTIME:?apptainer/singularity/docker}"
: "${RUNTIME_EXE:?実行ノードのruntime executable}"
: "${BASE_URI:?実際の固定OCI digestまたはfile:///absolute.sif}"
: "${BASE_PYTHON:?image自身のPython}"
: "${BASE_SHELL:?image自身のBash}"
: "${REQUIREMENTS:?自己完結の固定requirementsファイル}"
: "${CHECK_OUTPUT:?未作成の絶対出力ディレクトリ}"
python "$BPCE_ROOT/tools/verify_runtime.py" \
  --runtime "$RUNTIME" --runtime-executable "$RUNTIME_EXE" \
  --image "$BASE_URI" --base-python "$BASE_PYTHON" --base-shell "$BASE_SHELL" \
  --requirements "$REQUIREMENTS" --require-additions --attempts 2 \
  --output "$CHECK_OUTPUT"
```

Docker固有設定が必要なら`--backend-options /absolute/options.json`を追加する。これはSystem側execution.backend_optionsと同じ形式。認証用configが必要な場合も明示し、runtimeを切り替えるだけのためにrequirements/setupを分岐しない。

このツールは専用outputに小さいGit管理fixtureを生成し、既存resolverで固定し、**配布されたruntime.pyz**を選択runtimeに対して起動する。ユーザーのrepoへcommitしない。read-only input、workdir、setupが作ったtool、result、CER validate、2回attemptの旧CER非上書きを確認する。Baseに追加依存を導入したかも区別する。

`report.json`の成功値は`PASS_RUNTIME_SMOKE`であり、Benchpark/Spack E2Eや性能ベンチマークのPASSではない。失敗時は同じoutputを上書きせず、report、workerログ、runs/*/cer.jsonを保存し、新しいoutputで再試行する。

## 4. GPU実受入

同じコマンドへ`--gpu nvidia --expected-gpus <割当数>`、または`--gpu amd --expected-gpus <割当数>`を追加する。指定したbackendに対応するimage PyTorchを使う。probeはGPU可視性・CUDA/HIP一致・device countを確認した後、GPU tensorの行列積と結果を検証する。device名と計算結果の確認をsmoke.jsonに保存する。

これは機能検証であり性能比較ではない。GPU UUID/デバイス割当、Slurm cgroup/ROCr numeric対応、ドライバとimageの互換性は対象サイトで記録する。DockerのSlurm numeric CUDA ordinalは意図的に拒否する。UUIDで矛盾なく宣言できる構成を使用する。

## 5. Benchpark/Ramble上の受入

通常のサイトSystem/Experimentを使用するのが本番経路。runtime・imageを供給するSystemを3つ作り、同じExperimentで`+container`を選択する。既存のSpack試験も別の新規workspaceで実行する。

開発用の標準例を使う場合、`tools/configure_examples.py`で一時的な`-C`scopeを作り、`examples/systems/bpce-runtime`を使用できる。`-C`はサンプルを露出するためだけで、通常の拡張利用に必要な操作ではない。

```bash
# 利用中のBenchpark版の通常の引数・dest規約に合わせる。
benchpark -C "$EXAMPLE_SCOPE" system init --dest="$SYSTEM_DEST" \
  bpce-runtime "container_runtime=$RUNTIME" "runtime_executable=$RUNTIME_EXE"   "base_uri=$BASE_URI" "base_python=$BASE_PYTHON" "base_shell=$BASE_SHELL"
benchpark -C "$EXAMPLE_SCOPE" experiment init --dest="$EXPERIMENT_DEST" \
  "$SYSTEM_DEST" 'common-base-smoke +container'
benchpark setup "$EXPERIMENT_DEST" "$RUNS_DIRECTORY"
source "$RUNS_DIRECTORY/setup.sh"
ramble --workspace-dir "$RAMBLE_WORKSPACE" workspace setup
ramble --workspace-dir "$RAMBLE_WORKSPACE" on
ramble --workspace-dir "$RAMBLE_WORKSPACE" workspace analyze --formats json
benchpark cer list "$RAMBLE_WORKSPACE"
```

本段落のCLIは対象Benchpark checkoutで未実行。既存サイトの構文に合わせ、ログを残す。`common-base-smoke`は既存のCPU機能smokeであり、実GPU計算も追加package導入も自動では証明しない。セクション3/4のprobeまたは同等の明示したExperimentを別途実行する。

FoMを含む全具体条件とrepeatの実行・CER件数・状態を照合し、Rambleの成功表示だけで判定しない。stock SpackとExtension導入後Spackのbuild/run/analyzeを同一条件で確認する。`verify_upstream.py`のpatch/configuration検査や`verify_package.py`のCLI fixtureは、実Spack buildの代用にならない。

## 6. 正式v1.0判定の記録

3 runtime × CPU/mount/setup/非空requirements/CER、対象3 runtime × CUDA/ROCm、stock/導入後Spack、3 runtimeの+container workflowを実ログで埋める。N/Aを必要条件のPASSに読み替えない。実験ごとにartifact hash、設定、runtime/image/driver、GPU割当、command、exit code、FoM、CER path/hashを保存する。

修正が必要になった場合は、対象箇所だけでなく`tools/review_all.py`でC01〜C26とR01〜R24を順番に全件再検証する。既存の失敗roundを消さず、新しいround名と全項目notesを使う。実機結果を記載する場合は対応ログを必ず根拠にする。
