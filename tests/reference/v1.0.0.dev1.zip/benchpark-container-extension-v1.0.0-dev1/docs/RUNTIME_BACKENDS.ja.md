# Runtime backend契約 — 1.0.0.dev1

## 1. 実装と保証を区別する

Apptainer、Singularity、Dockerの選択・image解決・CLI・lifecycle・CER観測を実装した。ここで「実装済み」は実機受入PASSを意味しない。実行環境には3 runtimeもGPUもBenchpark/Rambleもなく、ネイティブ実行の受入条件は未検証。Podman自体は実装していない。

System/Experiment/Coreの責務は従来通り。runtime切替はSystem初期化時の設定であり、既存workspaceのplanやCERを後から書き換えない。runtimeを変更した比較には別System/Experiment/workspaceを作る。

## 2. 共通APIと所有権

|API / 型|責務|
|---|---|
|`ImageRef(kind, reference, identity, details)`|SIFとOCIを区別した固定参照。OCIはローカルファイル扱いしない|
|`Mount(source, target, readonly)`|ホストsourceとcontainer target、読取り専用条件。未対応の区切り文字やpath traversalを拒否|
|`ExecutionRequest`|image、mounts、environment、workdir、command argv、accelerator。CLIオプションは持たない|
|`RuntimeCapabilities`|GPU/read-only/workdir/immutable imageの要求を検証。入力image種別はbackendの解決処理でも検査|
|`validate_config(settings)`|System設定を副作用なく検証。init時に計算ノードの実行ファイルを探さない|
|`observe_runtime()`|実行ノードでexecutable/versionを確認。Dockerはdaemonの限定情報も観測|
|`resolve_image(base, timeout)` / `observe_image(image)`|固定imageを解決・確認し、共通上位構造へ固有観測を返す|
|`build_command(request)`|実行argvを作成。Dockerでは未実行のcreate/start planを保持|
|`command_scope(command)`|実行前確認と実行後cleanup。prep/benchmarkが同じscopeを使う|
|`attach_attempt(path)` / `close()`|attempt別のruntime証跡と所有資源の後始末。ユーザーの成果物・他containerを削除しない|

`argv()`は既存preparation呼出形式からExecutionRequestへの互換adapter。`version()`も独立して残す。daemon型runtimeを安全に終了するため、CLI生成だけでなくscope/closeを契約に含めた。scopeはコマンドをverified container IDのstartへ更新でき、呼出側は同じlistを実行しCERに記録する。

RuntimeBackendは信頼済みExtension内の拡張点であり、悪意あるplugin・daemonへのセキュリティ境界ではない。registryはAPI番号と登録名/class名を検証する。実際のruntime欠落や不適合時に別runtimeへfallbackしない。

## 3. System設定

既存schemaを保持し、`execution`に以下を宣言する。

```python
"execution": {
    "runtime": "docker",             # apptainer / singularity / docker
    "executable": "/usr/bin/docker", # 実行ノードの実体
    "worker_python": "/site/bin/python3",  # host側、containerにmountしない
    "image_cache": "/site/cache/bpce",
    "gpu": "none",                   # none / nvidia / amd（既存の値を維持）
    "backend_options": {
        "endpoint": "unix:///var/run/docker.sock",
        "network": "bridge",
        "ipc": "private",
        "shm_size": "64m"
    }
}
```

この例のpathはサイトで置き換える。Apptainer/Singularityでは`backend_options`は空または省略する。BaseのURI/tools、Experimentの固定requirements/setup、artifact宣言は別の既存項目に置く。

Docker固有の許可項目は次の通り。任意のextra CLI文字列は許可しない。

|設定|扱い|
|---|---|
|`endpoint`|ローカル絶対Unix socketのみ。既定は`unix:///var/run/docker.sock`|
|`config_dir`|任意。認証用Docker client設定の絶対ディレクトリ。未指定時は空のrun-local client設定。`proxies`による暗黙env注入は拒否|
|`gpu_devices`|CUDA: GPU/MIG UUIDまたは単体ホスト上のnumeric ID文字列。ROCm: `/dev/dri/renderD...`の明示一覧|
|`group_add`|任意の数値GID一覧。省略時はホスト補助グループ。UID:GIDはホスト実行者と一致させる|
|`network` / `ipc`|`bridge/host/none`、`private/host`。既定はbridge/private|
|`shm_size`|private IPC時のみ。既定64m、単位b/k/m/g。host IPCとの同時指定は拒否|
|`seccomp`|`default`または明示`unconfined`。自動で制限を解除しない|
|`cgroup_parent`|任意の明示した絶対cgroup path。これだけでscheduler統合を保証しない|
|`control_timeout_seconds`|create/inspect/cleanup等の制御CLI timeout。既定30秒、0超300秒以下|

rootless/userns-remap・remote daemonはホストbindの所有権とpathを別途設計・検証する必要があるため、この候補では明示停止する。ユーザーにDocker daemonの有効化・権限変更を自動実行しない。daemonを呼べる権限は運用側で判断する。

## 4. SIF family

ApptainerとSingularityは別class/name/version/executable。共通SIF処理を共有するが、Singularity cacheは独立namespaceを持ち、`SINGULARITY_CACHEDIR`を使用する。Apptainerの既存cache key/metadata形式は維持した。

`file:///absolute/base.sif`は初期化時hashを実行時に再確認する。OCI指定はimmutable digestを必須とし、選択runtimeでSIFへ変換してSIF hashを観測する。cacheのhash/metadata欠落・不一致は再pullで黙って修復しない。実行では`--cleanenv --containall --no-home --no-eval`、bind、pwd、明示envを使用する。カンマを含むenvはCSVとしてencodeする。

`--no-eval`等のオプションを提供するruntimeが必要。古いバージョンで未対応の場合、暗黙に弱いオプションへ落とさず失敗する。実際に動作確認済みの最低バージョンは今回確定していない。

## 5. OCI / Dockerの固定imageとlifecycle

1. `repository@sha256:...`でinspectし、明確なimage不存在の場合のみpullする。認証/daemon権限エラーを不存在として扱わない。
2. `RepoDigests`が要求repository digestを含むこと、`Id`がcontent-addressed IDであること、platformがホストと整合することを検証する。Docker Hubの表記alias以外、同じdigestを持つ別repositoryを同一指定として扱わない。
3. verified image IDを指定してcreateする。`--pull never --read-only --no-healthcheck`、明示ENTRYPOINT/argv/bind/envを使用する。
4. create後にImage ID、ENTRYPOINT/CMD、bind source/mode、image既定env＋要求envをinspectし、全て一致してからcontainer IDでstartする。
5. process終了・非zero・timeout・SIGINT/SIGTERMの後、所有labelとIDを確認して当該containerだけ`rm --force --volumes`する。global pruneは使わない。

読取り専用rootfsに対し、`/bpce`と結果artifactはrun-local書込み領域。`/tmp`と`/var/tmp`は一時tmpfs。imageに宣言された隠れた`VOLUME`は拒否する。未宣言のimage volumeを許して固定環境が置換されるのを避けるため。HOME/cacheの書込みが必要なworkloadでは、実験で適切な書込みartifactや環境変数を宣言する。

create timeout後にdaemon上の結果が確定できない場合は「削除済み」と報告しない。CER内の固有container名で運用者が状態確認する。所有label不一致は削除を拒否する。後始末失敗はbenchmarkが0で終了しても実験成功にしない。SIGKILL、ノード電断、daemon消失の後始末・CER完結は保証できない。

image ID、RepoDigests、platform、runtime/version、create/start、最終container state、cleanup結果をCERへ記録する。imageに含まれる全環境変数は検証用にメモリ内で参照するが、その全体をCERへdumpしない。明示したExperiment環境と実CLI自体には機密を入れないという既存制約を維持する。

## 6. GPUと割当

Apptainer/Singularityは`--nv`または`--rocm`。Docker CUDAは`--gpus`、ROCmは`/dev/kfd`と`/dev/dri`またはrender node、必要なGIDを使用する。CPU実行時のDockerはNVIDIA_VISIBLE_DEVICES=voidとし、CUDA image既定のallを継承しない。

Dockerの単体ホストnumeric GPU選択は、container内部のCUDA ordinalへ変換する。Slurmのnumeric ordinalはcgroup内で再番号付けされ得るためホストIDと決めつけず、UUID割当を要求する。宣言GPUとホストvisibilityが矛盾する場合も停止する。

ROCmで割当が制限されている場合はrender nodeを必須にし、暗黙の全`/dev/dri`公開を禁止する。ROCR/HIP visibilityの具体的な番号・node対応はサイトの実機検証が必要。CLIが生成されたことだけで、GPUが正しく割り当てられた・計算できた・公平に測定できたとはしない。NVIDIA/AMD両GPUの実確認は未実行。

## 7. 第4backendを追加する範囲

`backends/<new>.py`で契約を実装し、`backends/registry.py`へ登録、対応testsを追加する。`tools/build_runtime.py`を再実行するとbackend moduleは自動収集される。Core、integration、resolver、既存backend、preparation、CER schemaにruntime名の分岐を追加する必要はない。

`tests/test_runtime_extension_guards.py`はコピーしたrepoにtest-only第4backendを追加し、変更既存ファイルがregistryと生成済みpyzだけであること、`python -I -S`のnode workerから発見できることを確認する。この試験は「Podmanが動く」証拠ではない。新しいruntime特有の機能はbackend実装とその実機受入が必要。

## 8. 根拠と設計判断

以下はCLI/lifecycleに関して参照した公式資料。参照日2026-09-16。実機で使用したruntime版の証拠ではない。create/inspect/startを分けること、rootfulに範囲を限定すること、VOLUMEを拒否することは本実装の設計判断。

- Docker create: https://docs.docker.com/reference/cli/docker/container/create/
- Docker start/attach: https://docs.docker.com/reference/cli/docker/container/start/
- Docker run: https://docs.docker.com/reference/cli/docker/container/run/
- Docker image inspect: https://docs.docker.com/reference/cli/docker/image/inspect/
- Docker rm: https://docs.docker.com/reference/cli/docker/container/rm/
- Apptainer environment/no-eval: https://apptainer.org/docs/user/latest/environment_and_metadata.html
- Singularity exec: https://docs.sylabs.io/guides/latest/user-guide/cli/singularity_exec.html
- NVIDIA Container Toolkit GPU selection: https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/docker-specialized.html
- ROCm Docker devices: https://rocm.docs.amd.com/projects/install-on-linux/en/latest/how-to/docker.html
