# Benchpark Container Extension

Benchpark Container Extension adds **opt-in container execution** and **per-run reproducibility recording (CER)** to an **existing Benchpark installation**.

This project does **not** replace Benchpark and does not change Benchpark's default Spack workflow.

- Existing Benchpark + Spack remains the default.
- Container execution is enabled explicitly with `+container`.
- Container-specific implementation lives in this external repository.
- Benchpark Core only needs a small generic plugin seam plus a minimal compatibility change for non-Spack setup paths.

```text
Existing Benchpark
   |
   +-- normal experiment ----------> existing Spack path
   |
   +-- experiment +container ------> Benchpark Container Extension
                                      |
                                      +-- container image
                                      +-- requirements / setup.sh
                                      +-- artifacts / mounts
                                      +-- Apptainer execution
                                      +-- CER
```

## 1. Prerequisites

This README assumes that **Benchpark is already installed and usable**.

Before installing this extension, confirm that your existing Benchpark environment can complete its normal workflow, for example:

```bash
benchpark system init ...
benchpark experiment init ...
benchpark setup ...
ramble --workspace-dir ... workspace setup
ramble --workspace-dir ... on
ramble --workspace-dir ... workspace analyze --formats json
```

You also need:

- Python `>= 3.10` in the host environment used by Benchpark
- Apptainer on the execution node
- a container image for the target workload

The container image is expected to provide the runtime tools needed by the workload, such as Python, pip, Bash, framework libraries, CUDA/ROCm libraries, and other shared dependencies.

## 2. Install the extension into an existing Benchpark environment

The current Benchpark upstream does not yet provide the generic plugin seam required by this extension. An administrator therefore applies a small Core patch once to the existing Benchpark checkout.

Assume:

```text
/path/to/benchpark                     existing Benchpark checkout
/path/to/benchpark-container-extension this repository
/path/to/benchpark-python              Python used by the Benchpark environment
```

Generate and inspect the Core patch **without changing the checkout**:

```bash
/path/to/benchpark-python \
  /path/to/benchpark-container-extension/tools/patch_core.py \
  /path/to/benchpark \
  --output /tmp/benchpark-container-extension.patch

git -C /path/to/benchpark apply --stat /tmp/benchpark-container-extension.patch
git -C /path/to/benchpark apply --check /tmp/benchpark-container-extension.patch
```

After reviewing the diff, apply it:

```bash
git -C /path/to/benchpark apply /tmp/benchpark-container-extension.patch
```

Then install the external package into the **same host Python environment used by Benchpark**:

```bash
/path/to/benchpark-python -m pip install /path/to/benchpark-container-extension
```

The package installation itself does not rewrite Benchpark Core.

### Verify registration

```bash
benchpark --help
benchpark cer --help
```

The top-level help should show entries similar to:

```text
Installed external commands: cer
Installed experiment features: +container
```

## 3. Existing Spack workflows remain unchanged

Installing the extension does not automatically enable containers.

An existing experiment continues to use Benchpark's normal path:

```bash
benchpark experiment init \
  --dest=<experiment-name> \
  <initialized-system> \
  '<experiment-spec>'
```

No `+container` means the normal Benchpark/Spack behavior remains selected.

This property is a required compatibility condition of the extension.

## 4. Make an existing Benchpark System container-capable

Container execution is still driven by Benchpark's existing System and Experiment resources.

A container-capable System provides the **execution-side contract**, including:

- container runtime
- container image(s)
- Python executable supplied by the image
- shell supplied by the image
- image cache
- GPU passthrough mode when required

Conceptually:

```python
self.extension_settings = {
    "container": {
        "schema_version": 2,
        "execution": {
            "runtime": "apptainer",
            "executable": "apptainer",
            "worker_python": "...host Benchpark Python...",
            "image_cache": "/path/to/image-cache",
            "gpu": "none",
        },
        "base_images": {
            "pytorch-base": {
                "default": "release-a",
                "releases": {
                    "release-a": {
                        "uri": "file:///absolute/path/base.sif",
                        "tools": {
                            "python": "python3",
                            "shell": "bash",
                        },
                    }
                },
            }
        },
        "artifact_roots": {},
    }
}
```

See `examples/systems/bpce-local/system.py` for a complete functional example.

The System declares **what execution environment is available**. It does not contain model- or workload-specific dependency installation logic.

## 5. Make an existing Benchpark Experiment container-capable

The Experiment provides the workload-side requirements for container execution.

Typical declarations include:

- logical container-image requirement
- pinned requirements/lock text
- Git-managed setup scripts
- benchmark/model/dataset/config artifacts
- mount targets
- environment variables
- timeout
- protected packages already provided by the image

Conceptually:

```python
def get_extension_settings(self):
    return {
        "container": {
            "schema_version": 1,
            "base": "pytorch-base",
            "requirements": ["requirements/extra.txt"],
            "setup_scripts": ["setup/install-tool.sh"],
            "protected_packages": {"torch": "torch"},
            "artifacts": [
                {
                    "name": "script",
                    "kind": "script",
                    "source": "assets/benchmark.py",
                    "target": "/bench/benchmark.py",
                },
                {
                    "name": "result",
                    "kind": "result",
                    "target": "/results",
                },
            ],
            "environment": {},
            "timeout_seconds": 600,
        }
    }
```

See `examples/experiments/common-base-smoke/experiment.py` for a complete functional example.

## 6. Software-environment boundary

The extension follows a strict boundary:

```text
Host / Benchpark
    |
    +-- requirements / lock text
    +-- Git-managed setup.sh
    +-- benchmark / model / dataset / config
    |
    | mount
    v
Container image
    +-- Python
    +-- pip
    +-- Bash
    +-- framework / CUDA / ROCm / common libraries
```

The extension does **not** inject its own Python interpreter, pip executable, virtual-environment bootstrap, or package-manager binary into the container image.

Python dependencies are installed with the **Python/pip provided by the container image** into a run-local layer. Additional command/tool installation is performed by source-controlled setup scripts executed inside the container.

## 7. Run with the normal Benchpark workflow

Once the System and Experiment contain the required declarations, the user-facing workflow stays the same.

### Normal Spack path

```bash
benchpark experiment init \
  --dest=<name> \
  <initialized-system> \
  '<experiment-spec>'
```

### Container path

Add only the explicit feature selection:

```bash
benchpark experiment init \
  --dest=<name> \
  <initialized-system> \
  '<experiment-spec> +container'
```

Then continue with the normal Benchpark/Ramble sequence:

```bash
benchpark setup <initialized-experiment> <runs-directory>
source <runs-directory>/setup.sh

ramble --workspace-dir <workspace> workspace setup
ramble --workspace-dir <workspace> on
ramble --workspace-dir <workspace> workspace analyze --formats json
```

There is no separate container-only Benchpark CLI or required `source`, module, PYTHONPATH, or per-user extension configuration.

## 8. CER: per-run execution record

Each concrete container execution records the resolved and observed execution state, including:

- container image identity and SIF hash
- actual container runtime and runtime version
- resolved software environment
- requirements/setup inputs
- mounted artifacts and their identities
- benchmark parameters
- actual execution command
- host/runtime observations
- result status and failure phase
- separate attempts for retries

Example inspection:

```bash
benchpark cer list <workspace-or-run-root>
benchpark cer show <cer.json>
benchpark cer validate <cer.json>
```

A CER records what was actually executed. Existing records are not silently overwritten when an attempt is retried.

## 9. Architecture

The intended architecture is a small generic plugin seam in Benchpark Core and all Container/CER behavior in this external repository.

```text
Benchpark Core
  +-- small stdlib-only plugin loader
  +-- lifecycle seams at stable processing boundaries
             |
             | versioned plugin contract
             v
benchpark-container-extension
  +-- container feature resolution
  +-- configuration generation
  +-- workspace staging
  +-- container image resolution
  +-- requirements / setup scripts
  +-- Apptainer execution
  +-- CER
```

The Core patch must not contain Container-, Apptainer-, CER-, or workload-specific implementation logic.

The purpose of keeping the Core patch small is **upstream maintainability**, not cosmetic line-count minimization.

See:

- `docs/ARCHITECTURE.ja.md`
- `docs/PLUGIN_API.ja.md`
- `docs/review/COMPLIANCE.ja.md`

## 10. Example resources and `-C`

The repository contains example System/Experiment resources such as `bpce-local` and `common-base-smoke` for development and smoke testing.

Those examples may be exposed to Benchpark with a temporary `-C` configuration generated by `tools/configure_examples.py`.

**`-C` is not a requirement of normal Container Extension use.**

Production use is expected to use the existing site's Benchpark System and Experiment repositories, extended with the declarations described above.

## 11. Validation performed for the v1.0 baseline

The v1.0 baseline was validated on a DGX Spark-class Arm64 system against the `FN_apps` Benchpark branch in the following sequence:

```text
Stock Benchpark + Spack                    -> SUCCESS
Core plugin seam + Extension + Spack      -> SUCCESS
Core plugin seam + Extension + +container -> SUCCESS
```

The container path was observed using:

```text
Apptainer 1.5.0
actual `apptainer exec` command recorded in CER
container SIF identity recorded by SHA-256
four concrete smoke conditions completed
```

The smoke workload is a functional integration test, not a performance benchmark.

## 12. Development checks

For extension development:

```bash
python -m pip install -e '.[test]'
python tools/build_runtime.py --check
python tools/audit_architecture.py
python -m pytest -q
```

The project keeps a frozen architecture/compliance checklist under `docs/review/`. Changes to the implementation are expected to be re-reviewed from the first checklist item through the last rather than reviewing only the most recently changed item.

## 13. Current scope

v1.0 focuses on:

- existing Benchpark integration
- preservation of the default Spack workflow
- opt-in `+container`
- Apptainer execution
- container-image-based workload environment construction
- mounted external artifacts
- per-run CER

Features not explicitly validated in this release should not be inferred from the architecture alone.

## License

Apache-2.0. See `LICENSE` and `NOTICE`.
