# 1.0.0.dev1 実装・検証報告

## 結論

Apptainer/Singularity/Dockerのbackend実装、System選択、共通実行接続、CER観測、拡張性試験を追加した開発候補。正式v1.0の受入は未完了である。実機runtime/GPU/Benchpark/Spackを利用できないため、実機項目は保留のまま保存する。

## 実際に実行したローカル検証

|検証|結果・証跡|
|---|---|
|入力v0.6.1の既存試験|332 passed。`runtime-baseline/pytest.log`|
|現在の全件pytest|466 passed、skipなし。`runtime-final/pytest-isolated.log`|
|node worker/source一致|PASS。`runtime-final/bundle.log`|
|architecture audit|39 Python files / 0 issues。`runtime-final/architecture.log`|
|wheel構築|1.0.0.dev1 wheel生成。`runtime-final/build-wheel.log`|
|wheel clean install|実wheelを別targetへ非editable install。origin/entrypoints/CLI fixture PASS。`runtime-final/installed-wheel.json`|
|wheel/source比較|40ファイルbyte一致、3backendあり、Benchpark Core混入なし。`runtime-final/wheel-source-match.json`|
|全項目レビュー|runtime-02とruntime-03とも全50件を再判定。46 PASS_LOCAL、4 PENDING-EXTERNAL、0 FAIL。各roundの全pytestは466 passed|

既存332ケースを残し134ケースを追加した。旧試験3ファイルはruntime移設と追加要件に伴う接続点・期待条件だけを移行し、理由と代替guardを記録。その他の旧testファイルは入力ZIPとbyte一致、旧test関数名を全保持、旧storage runtime試験のassertは同一AST。

Docker daemonの動作はunit/integration内ではtest double。SIGTERM/SIGINTは実host child processで検査したが、実container起動ではない。package検査のCLI fixtureは本物のBenchparkやSpack buildではない。

## 保留とリリース条件

|ID|未実施|
|---|---|
|C23|今回版の実upstream checkout/Spack build/実workflow|
|R21|3runtimeのnative CPU/mount/非空requirements/setup/CER完走|
|R22|3runtimeで適用対象のCUDA/ROCm GPU可視性・割当・実計算|
|R23|stock Spack、導入後Spack、3runtimeの+container workflow/run/analyze|

`PASS_LOCAL`と`PENDING-EXTERNAL`を区別する。実機手順は`docs/RUNTIME_VALIDATION.ja.md`。根拠が揃うまで正式v1.0とはしない。旧READMEのDGX Spark/Apptainer成功記述は過去資料として保存し、新artifactの合格証拠にしない。

## 変更と保護

Core全体、benchpark_integration全体、tools/patch_core.py、resolver.py、artifacts.py、ramble_adapter.py、cer/recording.pyは入力ZIPから変更なし。runtime.pyはdispatch/lifecycle/観測へ整理、contracts.pyはregistry設定検証、preparation.pyは_container_runのlifecycle接続だけ。pip/setup/固定依存/保護package/activationの既存アルゴリズムを維持する。

SIF hash／OCI digest＋image IDを区別し、Dockerはcreate時にimage/argv/mount/envを照合してからverified container IDで起動する。timeoutや中断でもowned containerを後始末し、cleanup失敗を成功扱いしない。中間観測は番号付きimmutable event、最終CERは従来の非上書き保存。詳細は`docs/RUNTIME_BACKENDS.ja.md`。

Docker対応範囲はローカルLinux/rootful/non-usernsのEngine。remote/rootless、暗黙emulation、image-defined VOLUMEはこの候補で拒否。第4backend試験は新module+registry+生成bundleだけの変更を検査するが、Podman機能を実装済みとはしない。

## 失敗を含む履歴

初回327PASS/5FAILとruntime-01全件FAIL判定を保持。lifecycleの非上書き保存衝突、doubleのID使い回し、短すぎるprocess timeout、probe fixtureの期待値修正もログとともに保存した。全件試験中に外側tool timeoutが1件を中断した記録も削除せず、同一ソースの分離session再試験466PASSと分けて記録する。

`docs/review/runtime/FINDINGS.ja.md`と`TEST_MIGRATION.ja.md`に詳細。自己レビューは有限の仕様・ケースを検査したもので、未知の不具合や全実環境への無影響を証明しない。ユーザーの計算機へのinstall、Core apply、GitHub公開は行っていない。
