# runtime-01 全項目レビュー

外部E2Eは未実施。PASS_LOCALは実機合格を意味しない。

|ID|判定|根拠|
|---|---|---|
|C01|FAIL|既存332件中327成功。Docker拒否の旧仕様試験・旧mock・byte同一性試験5件がFAIL。更新理由を残して再検証が必要。|
|C02|FAIL|core/filesの入力hash比較、標準ライブラリloaderと既存test_small_core_seam。Coreの追加変更なし。|
|C03|FAIL|tools/patch_core.pyとcore/を入力hash比較。runtime層のみの変更でnative生成処理は変更なし。|
|C04|FAIL|src/benchpark_integration全体を入力hash比較。既存generation port/API境界は不変。|
|C05|FAIL|既存API/衝突試験を全実行。runtime追加ではregistry backend API=1検査を導入。|
|C06|FAIL|test_transparent_execution・test_small_core_seam。+container選択処理とSpack既定を変更しない。|
|C07|FAIL|同じhost package、同じ+container操作。backendはSystem設定。利用者別source/CLIは追加しない。|
|C08|FAIL|test_install_safety・test_small_core_seam。未選択provider障害分離は不変、欠落runtimeは失敗CER。|
|C09|FAIL|contracts.runtime_settingsがSystemのみでregistry検証。resolver.pyは入力hash不変。|
|C10|FAIL|preparation.pyの変更はimportと_container_run lifecycleのみ。pip/setup/検証関数のAST不変を追加検査予定。|
|C11|FAIL|runtime/AUTHORIZATION.jsonでruntime.py/contracts.py/preparation.pyのみの拡張理由を固定。旧byte試験の更新が必要。|
|C12|FAIL|reproducibility/requirements/artifactsを維持。SIF hashとOCI RepoDigests/Id検証をbackendに実装。追加負例試験が必要。|
|C13|FAIL|test_reference_equivalenceのold/new fixed snapshot差分は成功。integration snapshot処理を変更しない。|
|C14|FAIL|test_integration_source_guard・test_source_manifest・test_storage_runtimeの保護処理は維持。|
|C15|FAIL|test_transparent_execution・test_contract。software providerおよびRamble設定合成は入力hash不変。|
|C16|FAIL|concrete_plan/Ramble adapter不変。既存matrix/repeat/変数衝突試験を全実行。|
|C17|FAIL|runtimeはregistryへ移設。旧AdapterDoubleのpatch先が一致せず3件FAIL。assertは維持して接続点更新が必要。|
|C18|FAIL|cer/recording.py不変、schema v2/SIF既存観測キー保持。共通runtime観測/cleanup記録を追加。|
|C19|FAIL|CLIファイル不変、既存CER validate/diff/export/hash試験を全実行。|
|C20|FAIL|patch_core/install処理不変。生成/check/逆適用・汚れたCore拒否の既存試験。|
|C21|FAIL|初回試験5FAILを記録。Docker対応で旧拒否条件の意味を改訂し、凍結試験とmockの移行理由を文書化する。|
|C22|FAIL|benchpark_tuningとgeneric plugin試験を入力のまま全実行。|
|C23|PENDING-EXTERNAL|この環境にBenchpark/Ramble/Spack/container runtimesがなく、今回版の実workflowは未実行。|
|C24|FAIL|source/bundle整合とarchitectureはPASS。新wheel/clean install/README整合は後続roundで未実施。|
|C25|FAIL|旧Cリスト原本を保持しR01-R24を実装前に固定。全50件を順序通り再判定しログ/source hashを保存。|
|C26|FAIL|baseline=332PASS、初回=327PASS/5FAILを保存。実機結果とtest doubleを区別し正式v1.0扱いしない。|
|R01|FAIL|追加要件: Systemのruntimeをregistryで解決し、不明runtime/不正設定は停止。Experiment workflowは不変。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R02|FAIL|追加要件: ImageRef/ExecutionRequest/RuntimeBackendを定義しCLI差をbackendへ隔離。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R03|FAIL|追加要件: 既存SIF/pinned OCI・bind・宣言tools・environment・GPU・CER経路を維持。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R04|FAIL|追加要件: 独立backend、実executable/version、SINGULARITY_*の環境制御とcacheを区別。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R05|FAIL|追加要件: digestを必須にしRepoDigests/Id/platformを検証、実行は解決したimage IDで固定。SIFを拒否。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R06|FAIL|追加要件: scratch/read-only inputs/private outputs、workdir、空白pathを保持し不正encodingを拒否。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R07|FAIL|追加要件: 明示environmentとallocationを処理。Dockerのimage ENTRYPOINT/CMDで要求commandが変わらない。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R08|FAIL|追加要件: 3 runtimeのGPU CLIを検査。Docker選択GPUのcontainer内ordinalを扱い、allocationの黙った拡大を避ける。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R09|FAIL|追加要件: SIF --rocm、Docker kfd/render devices/groupの設定と不正値/曖昧allocationを検査。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R10|FAIL|追加要件: Base Python/pip/Bashによる同一requirements/setup処理。lifecycle接続以外の既存構築関数は不変。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R11|FAIL|追加要件: 成功/非zeroを区別しstdout/FoM、stderr、exit code、CER failure_phaseを保持。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R12|FAIL|追加要件: benchmarkとpreparation両方のtimeout/中断でprocess終了、runtime固有cleanup、失敗CERを保持。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R13|FAIL|追加要件: 所有labelとcontainer IDを確認し当該containerのみ削除。cleanup失敗を成功にしない。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R14|FAIL|追加要件: runtime名/version/executable、SIF hashまたはOCI digest/Id、実command/cleanupを保存。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R15|FAIL|追加要件: schema v2と既存SIF観測キー/CLI/hash検証/再試行非上書きを維持。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R16|FAIL|追加要件: 新backend+registry+testsのみでnode workerを含め利用可能。共通実行/Core/既存backend/CERは変更不要。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R17|FAIL|追加要件: 全backendの自動bundle、stdlib-only worker、wheel/source/versionの整合とclean installを検証。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R18|FAIL|追加要件: Core/integration/resolver/artifacts/CER recordingを入力ZIPから変更しない。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R19|FAIL|追加要件: 既存assertを弱めない。凍結byte比較のruntime拡張例外は理由・差分・代替検査を保存。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R20|FAIL|追加要件: 修正roundごとC01-C26とR01-R24を先頭から再判定しsource hashとログを保存。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R21|PENDING-EXTERNAL|追加要件: 3 runtime各々の実環境CPU smoke、mount、requirements/setup、CER完走は実ログを要求。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R22|PENDING-EXTERNAL|追加要件: 3 runtime CUDA/ROCmの実GPU確認は実ログを要求しCLI検査とは分ける。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R23|PENDING-EXTERNAL|追加要件: 新成果物でstock Spack/導入後Spack/+containerの実workflowを確認。過去PASSを流用しない。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
|R24|FAIL|追加要件: 実機未実行をPENDING-EXTERNALと記しv1.0正式releaseの合格条件と開発版完了を区別。 初回実装段階。専用試験/実機検証の証拠はまだ揃っていない。|
