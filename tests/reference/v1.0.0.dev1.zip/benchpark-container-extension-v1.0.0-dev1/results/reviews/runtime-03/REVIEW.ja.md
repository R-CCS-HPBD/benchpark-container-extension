# runtime-03 全項目レビュー

外部E2Eは未実施。PASS_LOCALは実機合格を意味しない。

|ID|判定|根拠|
|---|---|---|
|C01|PASS_LOCAL|元の332ケースを保持し134ケースを追加、全466件PASS。旧C01の「未実装Docker」は今回の明示追加要件により実装対象へ変更。MPI/自動Tune探索は追加せず、native runtime合格は別項目で保留。|
|C02|PASS_LOCAL|core/filesの入力hash比較、標準ライブラリloaderと既存test_small_core_seam。Coreの追加変更なし。|
|C03|PASS_LOCAL|tools/patch_core.pyとcore/を入力hash比較。runtime層のみの変更でnative生成処理は変更なし。|
|C04|PASS_LOCAL|src/benchpark_integration全体を入力hash比較。既存generation port/API境界は不変。|
|C05|PASS_LOCAL|既存API/衝突試験を全実行。runtime追加ではregistry backend API=1検査を導入。|
|C06|PASS_LOCAL|test_transparent_execution・test_small_core_seam。+container選択処理とSpack既定を変更しない。|
|C07|PASS_LOCAL|同じhost package、同じ+container操作。backendはSystem設定。利用者別source/CLIは追加しない。|
|C08|PASS_LOCAL|test_install_safety・test_small_core_seam。未選択provider障害分離は不変、欠落runtimeは失敗CER。|
|C09|PASS_LOCAL|contracts.runtime_settingsがSystemのみでregistry検証。resolver.pyは入力hash不変。|
|C10|PASS_LOCAL|test_reference_equivalenceでpreparation._container_run以外の既存関数/class/constantのAST一致。runtime専用試験は同じprepare呼出/lifecycleを通す。Base Python/pip/Bash方針を維持。|
|C11|PASS_LOCAL|固定AUTHORIZATIONとTEST_MIGRATIONの対象関数だけを変更。未変更機能はbyte/AST比較、Core/integration/resolver/artifacts/CER recorderは入力ZIP hash一致。|
|C12|PASS_LOCAL|既存requirements/models/artifacts拒否試験を全保持。SIF改変/metadata不正/OCI RepoDigests・Id・platform・mutable tag負例を追加。runtime_backendsの専用試験PASS。|
|C13|PASS_LOCAL|test_reference_equivalenceのold/new fixed snapshot差分は成功。integration snapshot処理を変更しない。|
|C14|PASS_LOCAL|test_integration_source_guard・test_source_manifest・test_storage_runtimeの保護処理は維持。|
|C15|PASS_LOCAL|test_transparent_execution・test_contract。software providerおよびRamble設定合成は入力hash不変。|
|C16|PASS_LOCAL|concrete_plan/Ramble adapter不変。既存matrix/repeat/変数衝突試験を全実行。|
|C17|PASS_LOCAL|旧storage runtime試験の全assertを同一ASTで保持しregistry接続へ移行。stdout/stderr、異常終了/activation/CER試験に加え実host processの中断試験を実施。container起動自体はdouble。|
|C18|PASS_LOCAL|cer/recording.pyは入力hash不変、schema2と旧SIF観測キーを保持。3 backend × 成功/失敗/prep失敗/timeout/interruptのCERと再試行非上書きを検査。|
|C19|PASS_LOCAL|CLIファイル不変、既存CER validate/diff/export/hash試験を全実行。|
|C20|PASS_LOCAL|patch_core/install処理不変。生成/check/逆適用・汚れたCore拒否の既存試験。|
|C21|PASS_LOCAL|旧332ケースを削除せず、変更試験3ファイルを理由付き移行。test_runtime_extension_guardsで旧試験名全維持と旧storage assertsのAST同一性を検査。|
|C22|PASS_LOCAL|benchpark_tuningとgeneric plugin試験を入力のまま全実行。|
|C23|PENDING-EXTERNAL|今回版の実Benchpark/Ramble/Spackが利用できず、実checkout/Spack build/全workflowは未実行。既存patch fixture/過去記述と区別。|
|C24|PASS_LOCAL|wheel buildと非editable一時targetへのinstall/実entry point/CLI fixtureに成功。同梱40ファイルsource byte一致、3backendとpyzありCoreなし。README/runtime契約/実機runbookを更新。|
|C25|PASS_LOCAL|旧C01-C26と新R01-R24を固定、失敗round runtime-01も保持。全50件の個別根拠を付して再レビュー。manifestにCore/src/tools/tests/examples/docs/CIのhashを保存。 runtime-02全50件=46PASS_LOCAL/4PENDING-EXTERNAL、全466test成功を確認した後、配布前に先頭から再実行。|
|C26|PASS_LOCAL|baseline・初期失敗・対象試験失敗と修正・全件再試験・wheel検証ログを保存。自己レビュー、tool timeout、実機未実行を区別。正式v1.0とは呼ばない。|
|R01|PASS_LOCAL|3runtimeのSystem設定positive、未知runtime/不正options/API番号拒否をtest_runtime_backends/capabilitiesで確認。initでcompute executableをprobeしない。|
|R02|PASS_LOCAL|ImageRef/Mount/ExecutionRequestとregistry API=1。capability拒否・重複mount・不正encodingを検査。共通execute/contracts/preparationにruntime名if分岐がないAST検査。|
|R03|PASS_LOCAL|既存SIF helper互換、cache key/metadataとhash観測を維持。SIF/pinned OCI/cache再利用・改変拒否・argv・envCSV・CUDA/ROCmの試験。実起動は未実施。|
|R04|PASS_LOCAL|独立class/name/executable/version、SINGULARITY_CACHEDIRとcache namespaceを検査。runtime名不一致を拒否。Singularityの実起動は未実施。|
|R05|PASS_LOCAL|RepoDigests/request repository、image Id、native platform、tag/SIF/hidden VOLUME拒否、daemon権限エラーをcache missにしない負例。created image mismatchはstart前に拒否。|
|R06|PASS_LOCAL|scratch/input/resultの既存materializationは不変。SIF/Docker bind RO/RW/workdir/path空白、区切り文字/重複target拒否、create後inspect一致を試験。実mountは保留。|
|R07|PASS_LOCAL|SIF cleanenv/no-eval/CSV、Docker明示ENTRYPOINT/argv/env、clientcontext/proxy注入拒否、create後env検証の試験。GPU visibilityはbackendで変換・記録。|
|R08|PASS_LOCAL|SIF --nv、Docker --gpus CSV/UUID/numeric内側ordinal、空割当拒否、Slurm曖昧numeric拒否を検査。GPU計算は未実行。|
|R09|PASS_LOCAL|SIF --rocm、Docker kfd/render nodes/数値GID/明示seccomp、制限割当のimplicit all拒否を検査。ROCr割当と実GPU計算は外部受入。|
|R10|PASS_LOCAL|requirements/setup/activation/protected Base/pins等の既存関数をAST一致で維持。scopeはprepareとbenchmark共通。probeは非空resolved_additionsを要求可能。|
|R11|PASS_LOCAL|3runtime double各々成功/nonzero/prep失敗/timeout/interruptedをexecuteからCERまで検査。実host subprocessのstdout/stderr・teeログを確認。|
|R12|PASS_LOCAL|test_runtime_signalsでprep/benchmark × SIGINT/SIGTERMを実childへ送信、子process終了・close・INTERRUPTED CERを確認。Docker timeout後cleanupはdaemon double。|
|R13|PASS_LOCAL|create→inspect→start verified ID→owned rmの順序、wrong image/foreign label/cleanup失敗/create結果不明・再利用拒否を検査。cleanup失敗後はexit0を返さない。|
|R14|PASS_LOCAL|SIF SHA256またはOCI digest/Id/platform、runtime/version/executable、実create/start/cleanupと限定daemon stateを記録。immutable event更新で旧記録を上書きしない。|
|R15|PASS_LOCAL|CER保存/CLIは未変更、schema2構造・従来観測キー・hash validate/diff/export・再attempt保護を既存と追加試験で確認。|
|R16|PASS_LOCAL|コピーrepoに第4backendとregistry登録だけを追加。pyz自動再生成後、python -I -Sでbackendを取得。既存変更はregistryと生成pyzだけとbyte比較。Podman実装とは区別。|
|R17|PASS_LOCAL|bundle自動収集/stdlib audit、40同梱file source一致、3runtime module、actual wheel clean target/entrypoints/CLI fixture。sdistも既存試験で確認。|
|R18|PASS_LOCAL|INPUT_RECEIPTのprotected directories/filesを全hash比較し差分なし。既存Core patchをさらに変更していない。|
|R19|PASS_LOCAL|TEST_MIGRATIONに3試験ファイルの移行理由。旧test関数名全維持、旧storage assertion AST一致、指定関数以外byte/AST一致を追加guard。|
|R20|PASS_LOCAL|50件を順番に出すharnessを実行し、試験失敗時にも46FAIL＋4pendingを漏らさない専用試験。初期roundと全ソースhash・全pytestログを保存。 runtime-02後、同じ全ケースをruntime-03で再実行。|
|R21|PENDING-EXTERNAL|実Apptainer/Singularity/Dockerが存在せずCPU/mount/非空requirements/setupのnative完走は未実行。verify_runtime.pyと手順を用意したが実行成功証拠ではない。|
|R22|PENDING-EXTERNAL|実CUDA/ROCm GPUが利用できず、3runtimeの実計算・GPU割当は未実行。CLIテストとhost Python processをGPU合格にしない。|
|R23|PENDING-EXTERNAL|新成果物に対するstock/導入後Spackと3runtimeの+container build/run/analyzeは未実行。過去Apptainer実績を転記しない。|
|R24|PASS_LOCAL|README/CHANGELOG/REPORT/runbookに1.0.0.dev1候補と明記。3runtime/GPU/Spackの外部受入を保留とし正式v1.0リリースを認定しない。|
