# SPDX-License-Identifier: Apache-2.0
"""Runtime-neutral example System; image and backend remain System declarations."""
import json
from pathlib import Path
import sys
from benchpark.directives import variant
from benchpark.system import System


class BpceRuntime(System):
    variant('container_runtime', default='apptainer', description='Registered runtime backend name')
    variant('runtime_executable', default='none', description='Explicit executable for the selected runtime')
    variant('base_uri', default='none', description='Pinned OCI repository@sha256 digest or file:///absolute/base.sif')
    variant('base_python', default='python3', description='Python supplied by this image')
    variant('base_shell', default='bash', description='Bash supplied by this image')
    variant('image_cache', default='~/.cache/benchpark/images', description='Host runtime cache')
    variant('gpu_passthrough', default='none', values=('none','nvidia','amd'), description='GPU policy')
    variant('backend_options_file', default='none', description='Optional absolute path to System backend-options JSON')
    variant('worker_python', default=sys.executable, description='Host Python for the stdlib-only worker')
    id_to_resources={'default':{'sys_cores_per_node':1,'scheduler':'mpi'}}

    def __init__(self, spec):
        super().__init__(spec)
        self.sys_cores_per_node=1
        self.scheduler='mpi'
        value=lambda name:spec.variants[name][0]
        if value('base_uri')=='none' or value('runtime_executable')=='none':
            raise ValueError('Declare base_uri and runtime_executable at System initialization')
        execution={'runtime':value('container_runtime'),'executable':value('runtime_executable'),
                   'worker_python':value('worker_python'),'image_cache':str(Path(value('image_cache')).expanduser().resolve()),
                   'gpu':value('gpu_passthrough')}
        if value('backend_options_file')!='none':
            path=Path(value('backend_options_file'))
            if not path.is_absolute():raise ValueError('backend_options_file must be absolute')
            execution['backend_options']=json.loads(path.read_text())
        self.extension_settings={'container':{'schema_version':2,'execution':execution,
            'base_images':{'pytorch-base':{'default':'release-a','releases':{'release-a':{
                'uri':value('base_uri'),'tools':{'python':value('base_python'),'shell':value('base_shell')}}}}},
            'artifact_roots':{}}}

    def compute_software_section(self):
        return {'software':{'packages':{}}}
