# SPDX-License-Identifier: Apache-2.0
"""Core-owned configuration boundary. Not a post-setup YAML transformer."""
import hashlib
from pathlib import Path
from benchpark.extension_api import (API_VERSION, ConfigurationContribution, ExtensionError,
    ExtensionDescriptor, ResolutionContext, SoftwareProvider, plain)
from benchpark.extensions import load_unique, NAME
from .options import source_root
from .io import file_hash, relative_path, read_system_snapshot, SNAPSHOT


def contributions(experiment):
    return tuple(getattr(experiment, "extension_contributions", ()))


def validate_contributions(values):
    owners, resources, variables, envs, modifiers = set(), set(), set(), set(), set()
    provider = None
    for c in values:
        if not isinstance(c, ConfigurationContribution) or not NAME.fullmatch(c.owner) or c.owner in owners:
            raise ExtensionError("Duplicate or invalid contribution owner")
        owners.add(c.owner)
        for mapping in (c.payload, c.variables, c.environment):
            if not isinstance(plain(mapping), dict):
                raise ExtensionError("Contribution section must be a mapping")
        if c.overwrite_policy != "fail":
            raise ExtensionError("Only overwrite_policy=fail is supported")
        if c.software_provider is not None:
            if not isinstance(c.software_provider, SoftwareProvider) or provider is not None:
                raise ExtensionError("Conflicting or invalid software-section providers")
            if not isinstance(plain(c.software_provider.section), dict):
                raise ExtensionError("Software section must be a mapping")
            provider = c.software_provider
        for values_, occupied, label in ((c.variables,variables,"variable"),(c.environment,envs,"environment")):
            for name in values_:
                if name in occupied:
                    raise ExtensionError("Extension " + label + " collision: " + name)
                occupied.add(name)
        for m in c.modifiers:
            if m["name"] in modifiers:
                raise ExtensionError("Duplicate modifier: " + m["name"])
            modifiers.add(m["name"])
        for r in c.resources:
            name = str(relative_path(r.target))
            if name in resources:
                raise ExtensionError("Duplicate resource: " + name)
            resources.add(name)
            actual = file_hash(r.source) if r.source else hashlib.sha256(r.text.encode()).hexdigest()
            if actual != r.sha256:
                raise ExtensionError("Resource changed before publication: " + name)
        for repo in c.modifier_repositories:
            relative_path(repo)
    return provider


def resolve_experiment(experiment, system_dir):
    selected = getattr(experiment.spec, "extension_selection", ())
    if not selected:
        return ()
    system = read_system_snapshot(system_dir)
    settings = (experiment.get_extension_settings() if hasattr(experiment, "get_extension_settings")
                else getattr(experiment, "extension_settings", {}))
    values = []
    for name in selected:
        desc = load_unique("benchpark.extensions", name)
        if not isinstance(desc, ExtensionDescriptor):
            raise ExtensionError("Invalid extension descriptor: " + name)
        if desc.requires_system and name not in system:
            raise ExtensionError("Missing saved System settings for %s; initialize a new System" % name)
        if desc.requires_declaration and name not in settings:
            raise ExtensionError("Experiment has no requirements/adapter declaration for " + name)
        snapshot = Path(system_dir) / SNAPSHOT
        context = ResolutionContext(name=experiment.spec.name,
            explicit=getattr(experiment.spec, "extension_explicit", {}),
            variants=dict(experiment.spec.variants.items()), system=system.get(name, {}),
            requirements=settings.get(name, {}), source_root=str(source_root(experiment.spec)),
            provenance={"system_snapshot_sha256": file_hash(snapshot) if snapshot.is_file() else None,
                        "preparations": getattr(experiment.spec, "preparation_records", {})})
        c = desc.resolver(context)
        if not isinstance(c, ConfigurationContribution) or c.owner != name:
            raise ExtensionError("Wrong contribution owner/type: " + name)
        values.append(c)
    validate_contributions(values)
    experiment.extension_contributions = tuple(values)
    return tuple(values)


def _has_requirements(section):
    if not section:
        return False
    if section.get("packages"):
        return True
    # Empty named environments are emitted even by disabled native helpers.
    if any(bool(value.get("packages")) or bool(set(value) - {"packages"})
           for value in section.get("environments", {}).values()):
        return True
    return any(value for key, value in section.items() if key not in ("packages", "environments"))


class RambleGeneration:
    """Single generation boundary: software selection and declarative additions.

    All normal native package_manager accesses remain untouched. Additional
    variables are added to the generated templates, before they are serialized.
    This adapter is owned by Core, not a plugin reading private Experiment state.
    """
    def __init__(self, experiment):
        self.experiment = experiment
        self.values = contributions(experiment)
        self.provider = validate_contributions(self.values)

    def software(self, native):
        if self.provider is None:
            return native()
        for helper in self.experiment.helpers:
            if _has_requirements(helper.compute_package_section()):
                raise ExtensionError("Selected provider cannot satisfy host/helper software: " + type(helper).__qualname__)
        return plain(self.provider.section)

    def finish(self, data):
        if not self.values:
            return data
        ramble = data["ramble"]
        names = {m["name"] for m in ramble.get("modifiers", [])}
        for c in self.values:
            for m in c.modifiers:
                if m["name"] in names:
                    raise ExtensionError("Duplicate modifier: " + m["name"])
                names.add(m["name"])
                ramble.setdefault("modifiers", []).append(plain(m))
        for app in ramble.get("applications", {}).values():
            for workload in app.get("workloads", {}).values():
                for experiment in workload.get("experiments", {}).values():
                    occupied = set(ramble.get("variables", {})) | set(app.get("variables", {})) | set(workload.get("variables", {})) | set(experiment.get("variables", {}))
                    var = experiment.setdefault("variables", {})
                    env = experiment.setdefault("env_vars", {}).setdefault("set", {})
                    for c in self.values:
                        for name, value in c.variables.items():
                            if name in occupied:
                                raise ExtensionError("Extension variable collision: " + name)
                            occupied.add(name); var[name] = plain(value)
                        for name, value in c.environment.items():
                            if name in env:
                                raise ExtensionError("Extension environment collision: " + name)
                            env[name] = plain(value)
        return data
