# SPDX-License-Identifier: Apache-2.0
"""Adapt external request options to the native spec, without class mutation."""
import copy
from pathlib import Path
from benchpark.extensions import entries, load_unique, NAME
from benchpark.extension_api import (ExtensionDescriptor, OptionSpec, ExtensionError,
    PreparerDescriptor, PreparationContext, PreparationResult, plain)


def source_root(spec):
    import benchpark.spec
    return Path(benchpark.spec.repo_path.filename_for_object_name(spec.name)).resolve().parent


def _options(spec, declared):
    native = {name for group in declared.values() for name in group}
    saved, selected, requirements = {}, [], {}
    known = set(entries("benchpark.extensions"))
    # A declaration also makes an explicit disabled flag meaningful even when
    # that plugin is not installed. Enabling still requires load_unique().
    known.update(getattr(spec.object_class, "extension_defaults", {}))
    for name in sorted(set(spec.variants) & known):
        if name in native:
            raise ExtensionError("Extension option conflicts with existing variant: " + name)
        values = spec.variants[name]
        if len(values) != 1 or type(values[0]) is not bool:
            raise ExtensionError("Select %s with +%s or ~%s" % (name, name, name))
        options = (OptionSpec(name, False, "Enable installed extension " + name,
                             "boolean", (True, False)),)
        if values[0]:
            desc = load_unique("benchpark.extensions", name)
            if not isinstance(desc, ExtensionDescriptor):
                raise ExtensionError("Invalid extension descriptor: " + name)
            selected.append(name)
            options += tuple(desc.options)
            for key, value in plain(desc.required_variants).items():
                if key not in native:
                    raise ExtensionError("Extension requires an unknown native option: " + key)
                if key in requirements and requirements[key] != value:
                    raise ExtensionError("Extension native-option conflict: " + key)
                requirements[key] = value
        for opt in options:
            if opt.name in native or opt.name in saved or not NAME.fullmatch(opt.name):
                raise ExtensionError("Duplicate/invalid extension option: " + opt.name)
            if opt.kind not in ("boolean", "string", "integer", "float"):
                raise ExtensionError("Unknown option type: " + opt.kind)
            saved[opt.name] = dict(owner=name, name=opt.name,
                default=plain(opt.default), description=opt.description,
                kind=opt.kind, choices=plain(opt.choices), multi=opt.multi)
    return saved, selected, requirements


def _equal(values, value):
    return [str(x) for x in values] == [str(value)]


def prepare_spec(spec):
    """Apply declarative request changes once, before native validation.

    Incoming request remains unchanged. Existing native options and package
    managers use the original concretizer, rather than runtime getter overrides.
    """
    if not spec.name:
        return spec
    if hasattr(spec, "extension_schema"):
        return spec
    from benchpark.spec import VariantMap
    declared = spec.object_class.variants
    explicit = plain(dict(spec.variants.items()))
    # Features are opt-in: declaration defaults must never select an execution
    # provider. Only explicit boolean options in this request reach _options().
    # Legacy extension_defaults keys are used there solely to recognize an
    # explicit disabled flag if the corresponding plugin is not installed.
    schema, selection, required = _options(spec, declared)
    settings = plain(getattr(spec.object_class, "extension_request_settings", {}))
    defaults = {name: plain(v.default) for when, group in declared.items()
                if not when.variants for name, v in group.items()}
    updates, records = {}, {}
    for name in sorted(set(settings) & set(spec.variants)):
        if name not in entries("benchpark.preparers"):
            raise ExtensionError("Requested preparer is not installed: " + name)
        desc = load_unique("benchpark.preparers", name)
        if not isinstance(desc, PreparerDescriptor):
            raise ExtensionError("Invalid preparer descriptor: " + name)
        value = spec.variants[name]
        if _equal(value, desc.inactive_value):
            continue
        if len(value) != 1 or not NAME.fullmatch(str(value[0])):
            raise ExtensionError("One named request preset must be selected: " + name)
        ctx = PreparationContext(spec.name, str(value[0]), explicit, defaults,
                                 settings[name], str(source_root(spec)))
        result = desc.prepare(ctx)
        if not isinstance(result, PreparationResult):
            raise ExtensionError("Invalid preparation result: " + name)
        for key, item in plain(result.overrides).items():
            if key not in defaults or isinstance(item, (dict, list)):
                raise ExtensionError("Preparer must change a declared scalar native option: " + key)
            if key in spec.variants and not _equal(spec.variants[key], item):
                raise ExtensionError("CLI/preset conflict: " + key)
            if key in updates and updates[key] != item:
                raise ExtensionError("Preparer conflict: " + key)
            updates[key] = item
        records[name] = plain(result.provenance)
    for key, value in required.items():
        if key in updates and updates[key] != value:
            raise ExtensionError("Preparer/extension conflict: " + key)
        if key in spec.variants and not _equal(spec.variants[key], value):
            raise ExtensionError("Explicit option conflicts with selected extension: " + key)
        updates[key] = value
    if not schema and not updates and not records:
        return spec
    merged = copy.copy(spec)
    merged._variants = VariantMap(spec.variants)
    for key, value in updates.items():
        if key in merged.variants:  # Native VariantMap rejects duplicate assignment.
            continue
        merged.variants[key] = value if type(value) is bool else str(value)
    merged.extension_schema = schema
    merged.extension_selection = selection
    merged.extension_explicit = explicit
    merged.preparation_records = records
    return merged


def effective_schema(spec, declared):
    """All native validation passes use the same per-spec schema."""
    from benchpark.spec import Spec
    from benchpark.variant import Variant
    saved = getattr(spec, "extension_schema", {})
    if not saved:
        return declared
    result = {when: dict(group) for when, group in declared.items()}
    additions = {}
    for name, o in saved.items():
        if o["choices"]:
            validator = tuple(o["choices"])
        elif o["kind"] == "boolean":
            validator = lambda v: type(v) is bool
        elif o["kind"] == "integer":
            validator = int
        elif o["kind"] == "float":
            validator = float
        else:
            validator = str
        additions[name] = Variant(name, o["default"], o["description"],
                                 values=validator, multi=o["multi"])
    result.setdefault(Spec(), {}).update(additions)
    return result
