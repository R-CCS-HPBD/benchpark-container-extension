# SPDX-License-Identifier: Apache-2.0
"""Core-owned, separately testable adapters; no Container implementation."""
