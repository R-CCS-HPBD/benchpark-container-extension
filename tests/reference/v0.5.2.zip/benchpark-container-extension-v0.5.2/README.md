# Benchpark Container Extension — 0.5.2.dev0

この版は、実機試験で繰り返し露出した「ExtensionがContainerのsoftware environmentへ入り込みすぎる」問題を設計境界から修正した版です。

## 1. 固定した実行境界

Python依存の経路は次の1本だけです。

```text
Benchpark / Extension (host)
    |
    | read-only mount
    +-- requirements.txt / included lock/constraint text
    |
    v
Common Base Container
    +-- Base Python
    +-- Base pip
    |
    +-- <Base Python> -m pip install --prefix /bpce/python -r <requirements>
```

追加コマンドや個別の構築処理が必要な場合は次の経路です。

```text
Git-managed setup.sh
    |
    | read-only mount
    v
Common Base Container
    +-- Base Bash setup.sh
    +-- writable destination: /bpce/tools
```

**ExtensionからContainerへPython、pip、pip.pyz、resolver、venv/ensurepip bootstrap、package-manager binaryを持ち込みません。**

Python dependency pathでmountするsoftware inputはrequirements/lock/constraintの**テキストだけ**です。local wheel/sdist/VCS/direct-reference payloadは拒否します。特殊な取得・build・command installはGit管理されたsetup scriptに記述し、Container内で実行します。

Benchmark script、model、dataset、config等はExperimentが明示した通常のartifactとして別途read-only mountされます。これはPython installerの持込みとは別です。

## 2. Common Baseの責任

System定義がCommon Baseごとに以下を宣言します。

- Base image identity（digestまたはSIF SHA-256）
- Base Python executable
- Base Bash executable
- runtime（現版はApptainer）

BaseごとにPython/pipのversionが異なって構いません。その組合せ自体がBaseのsoftware environmentです。Extensionはpip versionを統一・upgradeしません。

## 3. Experiment側

Experimentは以下を宣言します。

- 使用するCommon Baseのlogical requirement
- requirements text
- setup scripts
- model/dataset/script/config等のartifact
- benchmark parameter

`+container`を明示した場合だけContainer extensionが有効です。無指定時のBenchpark/Spack既定動作は変更しません。

## 4. Validationの守備範囲

- static: requirementsのexact pin、入力hash、model revision、mount安全性
- Base tool preflight: 宣言されたBase Python/pip/Bashが実Container内で利用できること
- dependency delta: **同じBase pip**でinstall前後を観測し、追加による新規不整合を検出
- protected package: Base packageがprivate prefixでshadowされていないこと
- runtime: mount/command/import/exit/timeout
- CER: resolved条件、観測Base、追加layer、setup command、benchmark結果をattempt単位で保存

`pip check`の文章はversion固有の正規表現で解釈しません。同一Base pipのbefore/afterの生diagnostic差分だけを使います。

## 5. 禁止している実装

- injected pip / Python / installer / resolver
- host-native `prepare_environment` / host pipでのsoftware construction
- requirements経路でのlocal `.whl`/sdist/package payload mount
- `pip --no-deps`でExtensionがresolver semanticsを置き換えること
- `pip --target` / `--ignore-installed`等でBaseを無視すること
- Python/Bash executableのlibrary fallback (`python3`, `/bin/bash`等)

詳細は `docs/ARCHITECTURE_INVARIANTS.ja.md` と `docs/EXECUTION_BOUNDARY.ja.md` を参照してください。

## 6. ローカル検査

```bash
PY=/path/to/python
"$PY" tools/build_runtime.py --check
"$PY" tools/audit_architecture.py
"$PY" -m pytest -q
```

unit testはContainer境界のcommand/data contractを検査します。hostをContainerの代用品としてsoftware constructionする`NativeRuntime`試験は削除しました。

## 7. RIKEN実機E2E

```bash
cd ~/benchpark-container-test
unzip benchpark-container-extension-v0.5.2.zip
source riken-ext-venv/bin/activate
python -m pip install -e './benchpark-container-extension-v0.5.2[test]'

OUT="$PWD/verify-riken-v052-runtime-$(date +%Y%m%d-%H%M%S)"
python benchpark-container-extension-v0.5.2/tools/verify_upstream.py \
  benchpark-riken \
  --output "$OUT" \
  --base-sif "$PWD/images/pytorch-bench-1.0.sif" \
  --run
```

この版について実RIKEN/Apptainer/SIF/GPUのE2Eは、成果物生成時点では未実施です。unit test合格と実機合格は区別します。
