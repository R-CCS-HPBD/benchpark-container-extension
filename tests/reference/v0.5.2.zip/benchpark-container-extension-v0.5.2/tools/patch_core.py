#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Create/check/apply a *diff* against a local Benchpark checkout.

No whole-file overlay. Exact structural anchors fail closed on unknown layouts.
The default writes a patch, never edits the checkout. --apply is explicit.
"""
import argparse
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
API_FILES = tuple(str(p.relative_to(ROOT / "core/files/lib/benchpark"))
                  for p in sorted((ROOT / "core/files/lib/benchpark").rglob("*.py")))


def replace(text, old, new, count=1):
    if text.count(old) != count:
        raise ValueError("Unsupported upstream layout: expected %d occurrence(s) of %r, got %d" %
                         (count, old[:110], text.count(old)))
    return text.replace(old, new)


def add_import(text):
    return replace(text, "import benchpark.spec\n",
                   "import benchpark.spec\nimport benchpark.extensions\n")


def transform(name, text):
    if "bpce:" in text:
        raise ValueError("Core already patched; use a NEW clean checkout: " + name)
    if name == "lib/benchpark/spec.py":
        text = replace(text, "        self._variants = other.variants\n",
            "        self._variants = other.variants\n"
            "        # bpce: preserve generic request metadata\n"
            "        for field in ('extension_schema', 'extension_selection',\n"
            "                      'extension_explicit', 'preparation_records'):\n"
            "            if hasattr(other, field):\n"
            "                import copy\n"
            "                setattr(self, field, copy.deepcopy(getattr(other, field)))\n")
        text = replace(text, "        return ConcreteExperimentSpec(self)\n",
            "        # bpce: prepare native options before concretization\n"
            "        from benchpark.extension_support.options import prepare_spec\n"
            "        return ConcreteExperimentSpec(prepare_spec(self))\n")
        start = text.index("    def _concretize(self):")
        end = text.index("\n\nclass ConcreteExperimentSpec", start)
        part = text[start:end]
        if part.count("self.object_class.variants") < 3:
            raise ValueError("Unknown concretizer schema handling")
        part = part.replace("self.object_class.variants", "variant_schema")
        part = replace(part, "    def _concretize(self):\n",
            "    def _concretize(self):\n"
            "        # bpce: one per-spec schema for every validation pass\n"
            "        variant_schema = self.object_class.variants if self.name else {}\n"
            "        if self.name and isinstance(self, ExperimentSpec):\n"
            "            from benchpark.extension_support.options import effective_schema\n"
            "            variant_schema = effective_schema(self, variant_schema)\n")
        text = text[:start] + part + text[end:]
    elif name == "lib/benchpark/cmd/system.py":
        text = replace(text, "        system.write_system_dict(destdir)\n",
            "        system.write_system_dict(destdir)\n"
            "        # bpce: freeze optional namespaced System declarations\n"
            "        from benchpark.extension_support.io import save_system_snapshot\n"
            "        save_system_snapshot(system, destdir)\n")
    elif name == "lib/benchpark/cmd/experiment.py":
        text = replace(text, "    experiment.system_spec = system_spec\n",
            "    experiment.system_spec = system_spec\n"
            "    # bpce: resolve through the public extension contract\n"
            "    from benchpark.extension_support.generation import resolve_experiment\n"
            "    resolve_experiment(experiment, args.system)\n")
        text = replace(text, '        experiment.write_ramble_dict(f"{destdir}/ramble.yaml")\n',
            '        experiment.write_ramble_dict(f"{destdir}/ramble.yaml")\n'
            '        from benchpark.extension_support.storage import publish_experiment\n'
            '        from benchpark.paths import paths\n'
            '        publish_experiment(experiment, destdir, args.system, upstream_root=paths.benchpark_root)\n')
    elif name == "lib/benchpark/experiment.py":
        if re.search(r'values=.*["\']container["\']', text) or '_ramble_pm' in text:
            raise ValueError("Legacy Container edits found; use a clean upstream worktree")
        # Exactly ONE configuration generation boundary. Native package-manager
        # reads, compute_config/apps/package functions are NOT rewritten.
        text = replace(text, "    def compute_ramble_dict(self):\n",
            "    def compute_ramble_dict(self):\n"
            "        # bpce: declarative contributions at the generation boundary\n"
            "        from benchpark.extension_support.generation import RambleGeneration\n"
            "        generation = RambleGeneration(self)\n")
        text = replace(text, '"software": self.compute_package_section_wrapper(),',
            '"software": generation.software(self.compute_package_section_wrapper),')
        text = replace(text, "        return ramble_dict\n", "        return generation.finish(ramble_dict)\n")
    elif name == "lib/benchpark/cmd/setup.py":
        text = replace(text, "    workspace_dir = pathlib.Path(experiments_root) / experiment_id\n",
            "    workspace_dir = pathlib.Path(experiments_root) / experiment_id\n"
            "    # bpce: check protection BEFORE native deletion; stage later\n"
            "    from benchpark.extension_support.storage import WorkspaceSession\n"
            "    extension_workspace = WorkspaceSession(experiment_src_dir, workspace_dir)\n")
        text = replace(text,
            "    symlink_tree(configs_src_dir, ramble_configs_dir, include_fn)\n"
            "    symlink_tree(experiment_src_dir, ramble_configs_dir, include_fn)\n",
            "    extension_workspace.stage(ramble_configs_dir, configs_src_dir, symlink_tree, include_fn)\n")
        text = replace(text,
            '    os.symlink(\n        choice_template,\n        ramble_configs_dir / "execute_experiment.tpl",\n    )',
            '    extension_workspace.template(\n        choice_template,\n        ramble_configs_dir / "execute_experiment.tpl",\n    )')
        text = replace(text,
            '    symlink_tree(\n        source_dir / "systems" / "common",\n        ramble_spack_experiment_configs_dir,\n        include_fn,\n    )',
            '    extension_workspace.common(\n        source_dir / "systems" / "common",\n        ramble_spack_experiment_configs_dir,\n        symlink_tree, include_fn,\n    )')
    elif name == "lib/main.py":
        if "import benchpark.cmd.cer" in text:
            raise ValueError("Existing CER CLI found; use a clean checkout")
        text = replace(text, '    print(helpstr)\n',
            '    print(helpstr)\n'
            '    # bpce: metadata-only help; no external modules loaded\n'
            '    from benchpark.extension_support.cli import print_extension_help\n'
            '    print_extension_help()\n')
        text = replace(text, "    init_commands(subparsers, actions)\n",
            "    init_commands(subparsers, actions)\n"
            "    # bpce: use actual builtin registry, not a copied command list\n"
            "    from benchpark.extension_support.cli import register_commands\n"
            "    register_commands(subparsers, actions, sys.argv[1:])\n")
    else:
        raise ValueError("Unknown patch target: " + name)
    ast.parse(text, filename=name)
    return text


TARGETS = ["lib/main.py", "lib/benchpark/spec.py", "lib/benchpark/experiment.py",
           "lib/benchpark/cmd/system.py", "lib/benchpark/cmd/experiment.py",
           "lib/benchpark/cmd/setup.py"]


def make_patch(checkout):
    checkout = Path(checkout).resolve()
    records, parts = [], []
    for rel in TARGETS:
        p = checkout / rel
        if p.is_symlink():
            raise ValueError("Refusing symlinked Core file: " + rel)
        old = p.read_text(encoding="utf-8")
        new = transform(rel, old)
        records.append({"path": rel, "old_sha256": hashlib.sha256(old.encode()).hexdigest(),
                        "new_sha256": hashlib.sha256(new.encode()).hexdigest()})
        parts.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                         fromfile="a/" + rel, tofile="b/" + rel))
    for filename in API_FILES:
        rel = "lib/benchpark/" + filename
        if (checkout / rel).exists() or (checkout / rel).is_symlink():
            raise ValueError("New Core filename already exists: " + rel)
        new = (ROOT / "core/files" / rel).read_text(encoding="utf-8")
        parts.extend(difflib.unified_diff([], new.splitlines(True),
                                         fromfile="/dev/null", tofile="b/" + rel))
        records.append({"path": rel, "old_sha256": None,
                        "new_sha256": hashlib.sha256(new.encode()).hexdigest()})
    return "".join(parts), records


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("checkout", type=Path)
    p.add_argument("--output", type=Path, default=Path("benchpark-extension-api.patch"))
    p.add_argument("--apply", action="store_true")
    p.add_argument("--reverse", action="store_true", help="Reverse a previously generated patch, after git apply --check")
    args = p.parse_args()
    try:
        root = args.checkout.resolve()
        if args.reverse:
            patch = args.output.read_text(encoding="utf-8")
            flags = ["--reverse"]
        else:
            modified = subprocess.run(["git", "-C", str(root), "diff", "--name-only", "HEAD"],
                                      capture_output=True, text=True, check=True).stdout.strip()
            if modified:
                raise ValueError("Use a clean worktree for Core patching; tracked changes are present")
            patch, records = make_patch(root)
            args.output.write_text(patch, encoding="utf-8")
            commit = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"], text=True,
                                    capture_output=True).stdout.strip() or None
            args.output.with_suffix(".json").write_text(json.dumps(
                {"api_version": 2, "head": commit, "files": records}, indent=2) + "\n")
            flags = []
        cmd = ["git", "-C", str(root), "apply", *flags]
        subprocess.run([*cmd, "--check", "-"], input=patch, text=True, check=True)
        if args.apply:
            subprocess.run([*cmd, "-"], input=patch, text=True, check=True)
            print("Applied checked diff to", root)
        else:
            print("Checked only; checkout unchanged. Patch:", args.output.resolve())
        return 0
    except (ValueError, OSError, subprocess.CalledProcessError) as e:
        print(str(e), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
