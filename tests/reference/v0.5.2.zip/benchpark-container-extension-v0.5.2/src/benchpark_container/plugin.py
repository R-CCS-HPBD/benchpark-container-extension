# SPDX-License-Identifier: Apache-2.0
"""Lightweight descriptors; no pip, runtime or repository activity on import."""
def describe():
    from benchpark.extension_api import ExtensionDescriptor, OptionSpec
    return ExtensionDescriptor(
        name="container", api_version=2,
        options=(
            OptionSpec("container_base", "default", "System Base logical name override"),
            OptionSpec("container_release", "default", "Release within the selected System Base"),
        ), resolver=resolve, required_variants={"package_manager": "user-managed"},
    )


def resolve(context):
    from .resolver import resolve
    return resolve(context)
