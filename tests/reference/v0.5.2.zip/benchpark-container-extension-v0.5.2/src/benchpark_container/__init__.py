# SPDX-License-Identifier: Apache-2.0
"""Container Extension. Importing the package has no registration side effects."""
__version__ = "0.5.2.dev0"
