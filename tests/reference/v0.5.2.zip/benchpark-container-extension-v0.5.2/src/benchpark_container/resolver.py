# SPDX-License-Identifier: Apache-2.0
"""Resolve saved System declarations and benchmark requirements into plain data."""
import hashlib
import json
from pathlib import Path
import re
import shlex

from benchpark.extension_api import (ConfigurationContribution, ResourceSpec, SoftwareProvider, plain)
from . import __version__
from .requirements import scan_requirements
from .contracts import base_tools, runtime_settings, validate_targets, DEPENDENCY_POLICY
from .artifacts import pin_external_artifacts
from .provenance import source_provenance
from .reproducibility import pin_image, validate_inputs, IMAGE
from .util import ValidationError, check_no_secrets, inside, safe_name, sha256, strict




def resource(path, target):
    return ResourceSpec(target=target, source=str(path), sha256=sha256(path))


def select_image(system, request, variants):
    bases = system["base_images"]
    logical = variants.get("container_base", ["default"])[0]
    if logical == "default":
        logical = request["base"]
    safe_name(logical, "Base name")
    if logical not in bases:
        raise ValidationError("System does not provide Base: " + logical)
    base = bases[logical]
    strict(base, ("default", "releases"), "Base", ("default", "releases"))
    release = variants.get("container_release", ["default"])[0]
    if release == "default":
        release = request.get("release", base["default"])
    safe_name(release, "release")
    if release not in base["releases"]:
        raise ValidationError("Unknown Base release: " + release)
    value = base["releases"][release]
    strict(value, ("uri", "platform", "sha256", "origin", "tools"), "image", ("uri", "tools"))
    if release.lower() == "latest":
        raise ValidationError("latest is not a fixed Container release")
    result = pin_image(value)
    result["tools"] = base_tools(value["tools"])
    result.update(logical_name=logical, release=release)
    return result


def requirements_resources(root, requested):
    """Snapshot exactly the input closure validated by the common reader."""
    scanned = scan_requirements(root, requested)
    return [ResourceSpec(target="inputs/" + rel, source=str(Path(root) / rel), sha256=h)
            for rel, h in scanned["files"].items()]


def resolve(context):
    s, q, variants = plain(context.system), plain(context.requirements), plain(context.variants)
    check_no_secrets(s); check_no_secrets(q)
    strict(s, ("schema_version", "execution", "base_images", "artifact_roots"), "System",
           ("schema_version", "execution", "base_images"))
    strict(q, ("schema_version", "base", "release", "requirements", "artifacts", "executables",
               "variables", "environment", "protected_packages", "smoke_imports", "timeout_seconds", "setup_scripts"),
           "Experiment", ("schema_version", "base", "executables"))
    if s["schema_version"] != 2 or q["schema_version"] != 1:
        raise ValidationError("System schema_version=2 with explicit execution/Base tools is required; Experiment schema remains 1")
    runtime = runtime_settings(s["execution"])
    requested_pm = plain(context.explicit).get("package_manager")
    if requested_pm and requested_pm != ["user-managed"]:
        raise ValidationError("Explicit package_manager conflicts with this user-managed application provider")
    for key in ("n_nodes", "n_ranks", "num_nodes"):
        if key in variants and variants[key] != ["1"]:
            raise ValidationError("Initial slice is one node/process: " + key)
    tune = variants.get("tune", ["none"])
    if tune != ["none"] and not plain(context.provenance).get("preparations", {}).get("tune"):
        raise ValidationError("Selected Tune was not prepared; declare extension_request_settings['tune']['allowed'] (v0.3), not legacy tuning_policy")
    root = Path(context.source_root).resolve()
    image = select_image(s, q, variants)
    req = q.get("requirements", [])
    if not isinstance(req, list) or not all(isinstance(x, str) for x in req):
        raise ValidationError("requirements must be a list of source-relative files")
    resources = []
    artifacts, targets, names = [], set(), set()
    roots = s.get("artifact_roots", {})
    for name, path in roots.items():
        safe_name(name, "artifact root")
        if not Path(path).is_absolute():
            raise ValidationError("System artifact root must be absolute")
    for a in q.get("artifacts", []):
        strict(a, ("name", "kind", "root", "path", "source", "target", "readonly", "sha256", "revision", "manifest", "manifest_sha256"),
               "artifact", ("name", "kind", "target"))
        name = safe_name(a["name"], "artifact name")
        target = a["target"]
        if (not isinstance(target, str) or not target.startswith("/") or ".." in Path(target).parts
                or any(c in target for c in ":,\n\r\x00") or target == "/"):
            raise ValidationError("Invalid mount target: " + repr(target))
        if target == "/bpce" or target.startswith("/bpce/") or name in names:
            raise ValidationError("Reserved/duplicate artifact: " + name)
        if any(target == t or target.startswith(t+"/") or t.startswith(target+"/") for t in targets):
            raise ValidationError("Overlapping mount targets")
        targets.add(target); names.add(name)
        b = dict(a)
        if a["kind"] in ("result", "log", "temporary", "cache"):
            if any(key in a for key in ("root", "path", "source")):
                raise ValidationError("Writable artifacts use private per-attempt directories")
            if a.get("readonly", False):
                raise ValidationError("Output cannot be read-only")
            b.update(readonly=False, location="attempt")
        elif "source" in a:
            if "root" in a or "path" in a or a.get("readonly", True) is not True:
                raise ValidationError("Fixed source artifact must be read-only")
            p = inside(root, a["source"], must_exist=True)
            if not p.is_file():
                raise ValidationError("Fixed source artifacts must be files; use a System root for datasets")
            res = resource(p, "inputs/" + str(p.relative_to(root)))
            if a.get("sha256") and a["sha256"] != res.sha256:
                raise ValidationError("Source artifact checksum mismatch")
            resources.append(res)
            b.update(readonly=True, location="resource", resource=res.target, sha256=res.sha256)
        else:
            if a.get("root") not in roots or "path" not in a or a.get("readonly", True) is not True:
                raise ValidationError("Input requires a known System root, relative path and read-only mode")
            if Path(a["path"]).is_absolute() or ".." in Path(a["path"]).parts:
                raise ValidationError("Input path escapes its System root")
            b.update(readonly=True, location="external", host_root=roots[a["root"]])
        artifacts.append(b)
    validate_targets(artifacts, image["tools"].values())
    artifacts = pin_external_artifacts(artifacts, variants)
    validation = validate_inputs(root, req, artifacts, variants)
    requirement_pins = validation["requirements"]["pins"]
    resources += [ResourceSpec(target="inputs/" + rel, source=str(root / rel), sha256=h)
                  for rel, h in validation["requirements"]["files"].items()]

    setup_scripts = q.get("setup_scripts", [])
    if not isinstance(setup_scripts, list) or not all(isinstance(x, str) for x in setup_scripts):
        raise ValidationError("setup_scripts must be a list of source-relative shell scripts")
    staged_setup_scripts = []
    for rel in setup_scripts:
        script = inside(root, rel, must_exist=True)
        if not script.is_file():
            raise ValidationError("setup script must be a regular file: " + rel)
        if script.suffix not in (".sh", ".bash"):
            raise ValidationError("setup script must be a .sh/.bash file: " + rel)
        check_no_secrets(script.read_text(encoding="utf-8"))
        target = "inputs/" + str(script.relative_to(root))
        resources.append(resource(script, target))
        staged_setup_scripts.append(target)

    executables = q["executables"]
    if not isinstance(executables, list) or len(executables) != 1:
        raise ValidationError("Initial adapter requires exactly one benchmark executable (which may contain multiple shell commands)")
    safe_name(executables[0], "executable")
    protected = q.get("protected_packages", {})
    if not isinstance(protected, dict):
        raise ValidationError("protected_packages maps distribution name to import module")
    for pkg, module in protected.items():
        safe_name(pkg)
        if not re.fullmatch(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*", module):
            raise ValidationError("Invalid import module")
    package_resources = Path(__file__).parent / "resources"
    for p in sorted(package_resources.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and not p.name.endswith(".pyc"):
            resources.append(resource(p, str(p.relative_to(package_resources))))
    # Resource collisions are permitted only for identical inputs, never last-wins.
    unique = {}
    for res in resources:
        if res.target in unique and res.sha256 != unique[res.target].sha256:
            raise ValidationError("Resource collision: " + res.target)
        unique[res.target] = res
    env = q.get("environment", {})
    if not isinstance(env, dict):
        raise ValidationError("environment must be a mapping")
    for k, v in env.items():
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", k) or not isinstance(v, (str, int, float)):
            raise ValidationError("Invalid environment declaration")
        if k.startswith(("BPCE_", "PIP_", "APPTAINER", "SINGULARITY")) or k in ("PATH", "PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "PYTHONNOUSERSITE", "PYTHONDONTWRITEBYTECODE"):
            raise ValidationError("Python environment ownership conflict: " + k)
    plan = {"schema_version": 1, "extension_version": __version__, "benchmark": context.name,
        "base": image, "runtime": runtime, "dependency_policy": DEPENDENCY_POLICY, "requirements": ["inputs/" + r for r in req],
        "setup_scripts": staged_setup_scripts,
        "source_provenance": source_provenance(root, setup_scripts),
        "requirement_pins": requirement_pins, "validation": validation,
        "resources": {name: r.sha256 for name, r in unique.items()},
        "artifacts": artifacts, "protected_packages": protected,
        "smoke_imports": q.get("smoke_imports", []), "environment": env,
        "parameters": {k: v[0] if len(v) == 1 else v for k, v in variants.items()},
        "explicit": plain(context.explicit), "provenance": plain(context.provenance),
        "export_variables": q.get("variables", []), "executables": executables,
        "timeout_seconds": q.get("timeout_seconds", 3600)}
    check_no_secrets(plan)
    return ConfigurationContribution(owner="container", payload=plan,
        variables={"bpce_python": '"$BPCE_BASE_PYTHON"'},
        modifiers=({"name": "bpce-execution", "mode": "standard"},),
        software_provider=SoftwareProvider(section={"packages": {}, "environments": {}}),
        resources=tuple(unique.values()), modifier_repositories=("modifiers",))
