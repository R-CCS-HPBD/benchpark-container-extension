# v0.5.2 Test Report

## 実機 v0.5.1 失敗の根本原因

Common Base の `python -m pip --version` を同一 attempt 内で2回 probe し、両方が `base-pip-version` という同じ immutable evidence stem を使っていた。2回目の `base-pip-version.command.json` publish が exclusive create に衝突し `FileExistsError` となった。

これは SIF / requirements / Base pip の異常ではなく Extension の evidence naming と duplicate probe の実装バグ。

## v0.5.2 修正

- Base pip version probeをtool preflightの1回に統合。
- 観測したpackage-manager recordを後段へ引き渡し、再probeしない。
- `_capture()` は同じ attempt の evidence stem が既に存在すれば、2本目のcommandを起動する前に `EVIDENCE_STEM_REUSED` として停止。
- architecture auditにduplicate literal evidence stem検出を追加。
- content-addressed concrete planは concurrent identical createをcreate-or-verifyとして許容し、異なる内容は拒否。
- software boundaryは変更なし。Python/pip/BashはCommon Base由来で、Extensionからinstallerをmountしない。

## 横並び監査

`atomic_json` / command evidence / concrete plan / image cache / CER finalization / CLI exportを用途別に確認した。詳細は `docs/audit/v0.5.1/EVIDENCE_COLLISION_AUDIT.ja.md`。

v0.5.2のaudit:

```text
architecture rules: PASSED_RULES; 28 Python files; 0 issues
```

新しいauditをv0.5.1へ適用すると、duplicate `base-pip-version` と concrete-plan publish raceを含む3項目を検出する。

## Tests

このartifact生成環境では1回の長いtool callにwall-clock制限があるためsuiteを分割して実行した。合計 **289 passed / 0 failed**。

```text
group A: 115 passed
storage/runtime: 22 passed
group B rest: 110 passed
legacy: 42 passed
TOTAL: 289 passed
```

- runtime bundle check: PASS
- package wheel: `benchpark_container_extension-0.5.2.dev0-py3-none-any.whl`
- installed-wheel / entry-point verification: PASS

## 未検証

v0.5.2のRIKEN実checkout + Apptainer + supplied SIF E2Eは未実施。次の実機試験で確認する。
