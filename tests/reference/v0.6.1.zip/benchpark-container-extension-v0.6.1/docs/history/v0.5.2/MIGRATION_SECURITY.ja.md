# Migration / Security — v0.5.0

v0.4.x以前のinitialized planはdependency policyが異なるため再利用しない。v0.5.0は`common-base-pip-requirements-v1`を要求する。

秘密情報はrequirements/setup/configへ埋め込まない。hostのAPPTAINER/SINGULARITY injection environmentはruntime側で除去し、宣言mountだけを使用する。

setup scriptは任意コードなので、Git tracking/hashはprovenanceであって安全性証明ではない。site/operatorがレビューする。
