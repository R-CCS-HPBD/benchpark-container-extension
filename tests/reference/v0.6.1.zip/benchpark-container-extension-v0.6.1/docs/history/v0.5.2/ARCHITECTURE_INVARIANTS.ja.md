# Architecture Invariants / Allowed / Forbidden — v0.5.0

この文書が現行実装の監査基準です。`docs/history` と過去版auditは履歴であり、現行仕様ではありません。

## Architecture Invariants

| ID | 不変条件 |
|---|---|
| A01 | `+container`明示時だけ有効。無指定は既存Spack/native挙動を維持する。 |
| A02 | Coreは汎用extension hookのみを持ち、Container固有のpip/image/mount/CER意味論を持たない。 |
| A03 | Common BaseのPython/pip/Bashをそのまま使う。Extensionは別Python/pip/resolver/installer/venv bootstrapをContainerへ注入しない。 |
| A04 | Python依存のContainer入力はrequirements/lock/constraint **text**のみ。local wheel/sdist/VCS/direct-reference package payloadはこの経路でmountしない。 |
| A05 | Python dependency installはContainer内で`<Base Python> -m pip`を実行する。host Python/pipでsoftware environmentを構築しない。 |
| A06 | Extensionはpip resolver semanticsを置き換えない。`--no-deps`, `--target`, `--ignore-installed`, injected constraints/resolverを使わない。requirementsに書かれた意味を選択したBase pipが処理する。 |
| A07 | SIFを変更しない。追加Python packageはattempt固有の`/bpce/python`、setup scriptのtoolは`/bpce/tools`へ置く。 |
| A08 | Python以外の追加command/build/installはGit管理setup scriptとしてmountし、Base BashでContainer内実行する。 |
| A09 | Base Python/Bashの名前・pathをlibraryが推測しない。System/Base declarationから得た値をpreflightからbenchmarkまで一貫使用する。 |
| A10 | Base digest/SIF hash、requirements text hash、setup script hash/Git provenance、artifact identity、実command、観測packageをCERへ残す。 |
| A11 | validationは層を越えない。dependency checkは同一Base pipのbefore/after差分を観測し、Base自体を別pipで再評価しない。 |
| A12 | 機械可読stdoutとruntime stderrを混ぜない。failure phase/command/log/exitを保存する。 |
| A13 | runtime.pyzはhost-side workerでありContainerへmountしない。ContainerへExtension resource treeをmountしない。 |
| A14 | unit testでhost-native environment builderをContainerの代替にしない。実Container E2Eは別gateとして扱う。 |
| A15 | `/bpce`配下はversioned private ABI。これは環境依存hard-codeとは区別する。 |

## Allowed assumptions

- 現版はLinux + Apptainer + single node/process/foregroundの初期slice。
- setup scriptはBash。Bashの配置はSystem/Base declarationで指定する。
- `python -m pip install --prefix`でimmutable Baseの外にattempt-local layerを作る。
- requirements parserによるexact-pin/hash/secret/pathのstatic validationはhostで行ってよい。install/resolutionは行わない。
- benchmark/model/dataset/configはExperimentの通常artifactとしてmountしてよい。
- Systemのサンプルが`python3`/`bash`を既定値として宣言することは許可。ただしproduction libraryのfallbackではない。

## Forbidden assumptions

1. Base pipの不足をExtension同梱pipで補う。
2. host pipとContainer pipが同じ挙動/versionであると仮定する。
3. testのhost PythonをCommon Base Pythonの代理としてdependency installする。
4. local wheelを「requirementsの一部だから」と自動mountする。
5. `--no-deps`等でExtensionがpip dependency semanticsを再定義する。
6. `python`, `python3`, `/bin/bash`が全Baseにあるとlibraryでfallbackする。
7. pip diagnostic proseの特定versionの文面を正常/異常判定に使う。
8. unit testsのpassだけでRIKEN/LLNL/Apptainer/GPU実機対応済みとする。
