# Implementation — v0.5.0

- `preparation.py`: host側はApptainer commandを組み立てるだけ。Base tool probe、Base pip install、setup script、post-validationはすべてContainer内commandとして実行。
- `requirements.py`: requirements textのstatic validationとtext-file closure snapshotのみ。package payloadのsnapshot機能は持たない。
- `runtime.py`: attempt scratch `/bpce`、input text/scripts `/bpce/inputs`、Experiment artifactsだけをbind。Extension resource rootはbindしない。
- `ramble_adapter.py`: host-side `runtime.pyz`をworker Pythonで起動。これはContainerへ渡さない。
- `audit_architecture.py`: injected installer、host-native builder、local package payload、pip semantics overrideの回帰を検出。
