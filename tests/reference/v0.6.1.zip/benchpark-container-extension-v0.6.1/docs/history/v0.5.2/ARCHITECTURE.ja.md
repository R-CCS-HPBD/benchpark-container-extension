# Architecture — v0.5.2.dev0

```text
Benchpark Core (generic hooks)
        |
        v
External Container Extension
  resolve declarations / snapshot text+scripts / CER
        |
        | host worker launches runtime only
        v
Apptainer
        |
        +-- Common Base SIF (Python + pip + Bash + framework/runtime)
        +-- /bpce/inputs   <- requirements text + setup scripts (ro)
        +-- Experiment artifacts (ro/rw as declared)
        +-- /bpce/python   <- Base pip additional layer (rw attempt scratch)
        +-- /bpce/tools    <- setup-script tool layer (rw attempt scratch)
```

System defines runtime and Common Base contracts once. Experiment selects a logical Base and declares workload/software delta. User workflow remains normal Benchpark with explicit `+container`.
