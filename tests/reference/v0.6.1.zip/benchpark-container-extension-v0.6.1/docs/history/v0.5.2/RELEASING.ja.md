# Release gates — v0.5.0

1. `tools/build_runtime.py --check`
2. `tools/audit_architecture.py` -> 0 issues
3. pytest全件pass（batch実行可）
4. wheel/package内容にpip.pyz/Python/package payloadがないこと
5. real Benchpark checkoutでnative equivalence
6. supplied SIF + ApptainerでContainer E2E
7. 実機未実施のgateはREADME/TEST_REPORTで未確認と明記
