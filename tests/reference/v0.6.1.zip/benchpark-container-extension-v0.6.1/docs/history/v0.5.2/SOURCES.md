# Sources / evidence scope — v0.5.0

## Direct requirements

The current architecture is grounded first in the agreed project requirements:

- default Benchpark/Spack behavior is unchanged unless `+container` is explicit;
- Common Base supplies Python, pip, Bash and the heavy software stack;
- the Extension does not inject/upgrade a Python interpreter, pip, resolver or installer into the Container;
- Python software input across the boundary is requirement/lock/constraint text;
- additional command/build installation is expressed as Git-managed Bash setup scripts and executed inside the Container;
- model/dataset/benchmark/config remain explicit Experiment artifacts;
- CER records the resolved and observed run environment.

## Upstream source compatibility targets

The verification tool is intended for the pinned RIKEN checkout and its pinned Ramble/Spack stack. `tools/verify_upstream.py` records actual commit IDs when run; this release package does not claim that gate has run merely because local unit tests pass.

Relevant upstream/public references used by prior design work include Python packaging entry points, pip requirement-file/install behavior, and the pinned Ramble loader/workspace APIs. These references explain interfaces; they do not supersede the execution-boundary requirements above.

## Evidence distinction

- `results/architecture-rules.json`: static regression guard for current source.
- `results/TEST_REPORT.ja.md`: local unit/package checks performed for this artifact.
- real Benchpark/Ramble/Apptainer/SIF/GPU evidence must come from a fresh `verify_upstream.py --run` output on the target system.
