# Additional Dependency Layer — v0.5.0

Common Baseはread-onlyのまま利用し、追加Python packageだけattempt-local `/bpce/python`へ入れる。

実行するpackage managerはCommon Baseの宣言済みPythonによる`python -m pip`だけ。Extensionはpipを同梱・upgrade・置換しない。また`--no-deps`でresolverを迂回せず、requirements textに書かれたdependency semanticsをそのBaseのpipへ渡す。

requirements/lockはexact `name==version`をstatic validationし、実install後にprivate prefixをinventory化する。Baseと同名distributionがprefixへ導入された場合はBase shadowとして停止する。requirementsに明示されていないtransitive packageが新規導入された場合も、再現性上の未固定追加として停止する。

`pip check`は同一Base pipでbefore/afterを実行し、afterで新しく増えたdiagnosticだけをdependency delta failureとする。diagnostic文面をpip version固有のregexでは分類しない。

local wheel/sdist/VCS/direct URLをrequirements経路でmountしない。特殊な取得/build/installが必要ならGit管理setup scriptへ記述し、Container内で実行する。
