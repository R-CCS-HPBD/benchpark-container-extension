# Core API — v0.5.0

Core変更はContainer固有実装ではなくgeneric extension lifecycle/storage hookとして維持する。Container extensionはentry pointから発見され、明示`+container`時のみresolve/generationへ参加する。Coreから`benchpark_container`、Apptainer、pip等をimportしない。
