# Execution Boundary — v0.5.0

## Containerへ渡してよいもの

- requirements / lock / constraint **text files**
- Git管理されたsetup `.sh` / `.bash`
- Experimentが明示したbenchmark/model/dataset/config等のartifact
- attempt固有scratch/output bind

## Containerへ渡してはいけないもの

- pip.pyz / pip wheel / pip source
- Extension用Python interpreter
- generic resolver/installer bundle
- ensurepip/venv bootstrap
- host site-packages
- Extension resource root (`runtime.pyz`, modifier repo等)

## Software construction

Python:

```text
Common Base Python
  -> python -m pip
  -> requirements text
  -> /bpce/python
```

Command/tool:

```text
Common Base Bash
  -> git-managed setup script
  -> /bpce/tools
```

ExtensionはhostからContainer runtimeを起動するだけで、software install commandそのものはContainer内で実行される。
