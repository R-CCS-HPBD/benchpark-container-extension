# Reproducibility validation — v0.5.0

固定対象: Base image digest/SIF SHA-256、requirements text hashesとexact pins、setup script bytes/Git provenance、model/dataset/artifact identity、resolved parameters、actual runtime/tool versions、constructed prefix inventory、command、result。

requirementsのstatic validatorはinstall/resolutionをhostで行わない。markersは選択したCommon Base pipが評価する。runtimeで実際に導入された追加distributionをinventory化し、宣言pinとの対応を確認する。

model revision文字列だけをbytes identityとは見なさない。manifest/hashがある場合は別途記録・検証する。既存condition/attemptを上書きしない。
