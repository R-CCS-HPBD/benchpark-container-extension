# Generic lifecycle seam v1

## 契約の位置

Core側の`benchpark.plugins`は標準ライブラリだけを使う。**生のSpec、System、Experimentをproviderへ渡さない**。設定を合成・保存・配置する実装は、外部パッケージの`benchpark_integration`にある。

Core protocol番号は`1`、移設したfeature descriptor API番号は従来の`2`。別の層の番号であり、混同しない。

## Discovery

```toml
[project.entry-points."benchpark.lifecycle.v1"]
container = "benchpark_integration.hooks:provider"
tune = "benchpark_integration.hooks:provider"

[project.entry-points."benchpark.cli.v1"]
cer = "benchpark_integration.hooks:cer_command"
```

lifecycle entry pointは、`api_version == 1`と`handle(event, context)`を持つproviderを返すfactory。importは選択時だけ行う。feature aliasが同じ`entry_point.value`を指す場合に一度だけdispatchする。異なるcoordinatorを同じ呼出しに選択した場合はエラーであり、暗黙の連鎖や順番はない。

CLI entry pointの戻り値は`api_version`, `help`, `setup_parser`, `handler`を持つ。組込みcommand名を優先し、選択していない外部commandはimportせずstubとしてhelpへ登録する。CLIの追加は独立で、Containerを有効化しない。

既存のfeature、preparer、command descriptor entry pointも外部broker内では引き続き利用する。Coreにはそのschema・検証コードを置かない。

## Dataとport

|event|入力|戻り値／副作用|
|---|---|---|
|`request`|`name`, 明示`variants`, `native_names`, native `defaults`, request `settings`, `declared_features`, `source_root`|`native`, `extension_variants`, `state`のdict。書込みなし|
|`system_saved`|宣言`settings`, `dest`|System snapshotをdestへ保存。通常System宣言にplugin情報がなければ呼ばない|
|`experiment_resolve`|`name`, 確定`variants`, plain `state`, 実験`settings`, `system_dir`, `source_root`|immutable contribution tuple。image/requirements/mountの解決は外部処理|
|`generation`|`values` contribution tuple|`software(native, helpers)`と`finish(ramble_dict)`を持つport|
|`experiment_saved`|`values`, `dest`, `system_dir`, `upstream_root`|既存形式のmanifest、plan、resourcesを固定保存|
|`workspace`|`source`, `output`|生成前にguard済みのWorkspaceSession。必要な配置段階で`.stage`, `.common`, `.template`を呼ぶ|

`request.native`はnative concretizerが検証する値。外部側でnative型を独自に再実装しない。`extension_variants`は外部側が検証済みの値。nativeに対する上書きは既存native optionとして検証される。

`state`はpickle可能なplain dictだけ。`extension_selection`, `extension_schema`, `extension_explicit`, `preparation_records`を含む。Coreはそれらの意味を解釈せず、owner routingに使うselectionと次段への受渡しのみを行う。

## 操作を許す例外

`generation.software`にはnative software生成・helper生成の**0引数callback**を渡す。未選択ならnative処理を呼ぶ。providerがsoftwareを置き換える場合もhelper依存を勝手に捨てず衝突を検査する。

`workspace`にはnativeのcopy関数とinclude predicateを渡す。拡張領域以外のファイルについて既存の選択規則を使うための限定操作であり、Spec全体やrepository objectを渡さない。

CLIは`argparse` subparserを扱う。これらのportはtrusted code同士の構造的契約であり、sandboxや権限制御ではない。callbackから`__self__`等を調べて内部objectへ介入する実装は禁止する。

## 未導入・失敗時

- 無指定：native。選択されていないfeatureの実装はimportしない。
- `+container`：providerが存在してAPIが合う場合だけ実行。欠落時はnativeへfallbackしない。
- `~container`：disabledとして保持。従来の宣言済みdisabled feature形式を扱う。
- 同名native option：nativeを優先。既存schemaをplugin名で上書きしない。
- 外部commandの同名衝突：既存command優先。外部同士は選択時エラー。
- 旧実験のowner markerがある：providerが消えてもnativeとして削除しない。
- 壊れたmarker：処理停止。壊れたpluginを自動修復・自動installしない。

## Versionと変更

semantic contractを変える場合はprotocol versionを変えるか、明示した互換変換を入れる。単なるupstream行番号の移動はpatch adapter側の問題。現行dataを作れないupstream仕様変更では、位置を合わせるだけで成功扱いしない。

本実装はv0.5.2で使用していた機能を対象にしている。native conditional variantが外部追加variantを条件式として参照すること、無関係なcoordinatorを任意に組み合わせることは保証対象外。
