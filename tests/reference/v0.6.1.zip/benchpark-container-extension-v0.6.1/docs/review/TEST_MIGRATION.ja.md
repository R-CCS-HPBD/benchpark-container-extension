# 試験の移設と「機能を落とさない」の根拠

基準は保存した`tests/reference/v0.5.2.zip`。実装前に元の289件をこの環境で実行し合格した。これは旧版の実機成功を新しい接続の成功とみなすものではない。

## 保持したもの

元の全test関数名を保存し、Container/Ramble runtime/追加依存/CERのテスト内容を維持する。さらにContainer実装のPythonファイル全体について、API import名とrelease番号以外が同一であることをテストする。13の主要runtime/environment/CER moduleはbyte同一を検査する。

## 変更したもの

|旧試験の内部参照|変更|理由|
|---|---|---|
|`benchpark.extension_api`|`benchpark_integration.api`|API実装をCoreから外部へ移したため|
|`benchpark.extensions`/`extension_support`|外部discovery/support|同じfeature処理・保存ロジックの配置変更|
|`prepare_spec(生Spec)`|patched `ExperimentSpec.concretize()`|生objectを外部へ渡さない新しい実接続を試験するため|
|`RambleGeneration(生Experiment)`|明示したcontribution＋native/helper callback|`tests/ports.py`はtest double用の便宜adapter。Core objectを外部実装へ渡す互換shimではない|
|`spec.extension_explicit`等|`spec.plugin_state[キー]`|pickleに保存するplain metadataの構造変更|
|旧helperが入力objectを返す同一性assert|入力不変と、patched concretizer結果の同じ値をassert|返却object identityは廃止したprivate API。機能値の検証は別差分テストで維持|
|feature load数|coordinator loadとfeature loadを区別|外部featureが未選択で読まれないことを維持。native無指定ではcoordinatorもloadしないテストを追加|

元のassertを一字一句維持したとは主張しない。private API再配置のための上記の変更を隠さず記録する。判定値を弱めたり、失敗ケースをskip/xfailで合格扱いにはしていない。

## 追加した確認

- 旧版と新版を別Pythonプロセスで起動し、21通りのrequest受理/拒否/値・metadataとSystem/実験snapshotのbytesを比較する。
- native concretizerの全method、`compute_ramble_dict()`以外のExperiment methodのAST同一性。
- provider未導入、未選択、破損、名前競合、API不一致、複数feature、独立report/CLI plugin。
- 拡張を外した後の保存済みworkspace保護。壊れたowner markerをnativeと誤認しない。
- 実際のGitでpatch check/apply/reverseし、Core以外のtracked/untracked資材を保持。出力先上書き、dirty Core、未知anchorを拒否。
- wheelへ隔離installし、実entry pointと新Core loaderでhelp/CER CLIを確認。source版が紛れ込まない。
- installed Containerだけでなく、移動したintegration brokerとTuneも同じソース版かを検証する。

`tests/fixtures/upstream_like`は本物のBenchpark由来の処理を含むが、repository/bootstrap依存をtest doubleにしたfixture。実RIKEN/LLNLの全起動・Spack build・Apptainer実行の証拠ではない。
