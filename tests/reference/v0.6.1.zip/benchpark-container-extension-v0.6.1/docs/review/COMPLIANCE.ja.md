# v0.6.0 リファクタリング遵守リスト（実装前に固定）

作成: 2026-09-16T02:00:10.233851+00:00

基準: この会話の最終合意、および添付v0.5.2ソース。古い設計案の同梱pip/Container自動有効化/巨大Core frameworkは採用しない。

判定: PASS（根拠あり）、FAIL（修正必要）、PENDING-EXTERNAL（この環境で実行不能）、N/A（範囲外、理由必須）。PASSは静的/単体/結合/実機のレベルを伴う。全件検査でFAILがなくなっても実機保留を合格扱いしない。

|ID|分類|必須条件|
|---|---|---|
|C01|機能維持|v0.5.2の公開済みCLI・設定・コンテナ準備・実行・CER・履歴保全を維持する。未実装Docker/MPI/自動Tune探索を実装済みとは扱わない。|
|C02|Core境界|Coreへの新規配置は標準ライブラリだけの小さい汎用loader/契約。Container/Tune/CER、設定合成、snapshot、staging、runtimeは外部パッケージ。|
|C03|追従性|既存処理の意味的境界に接続する。native concretizer/Spack生成アルゴリズム、クラス継承を変更せず、monkey patch・import経路ハイジャック・完成版上書きをしない。行数最少化より保守性。|
|C04|境界データ|Coreから生のSpec/Experiment/Systemを外部へ渡さない。文書化したデータと限定操作で接続。argparse登録、設定生成の遅延実行等の例外は明示し、権限を限定する。|
|C05|契約と衝突|hook APIをversion管理。重複provider/変数/resource/commandの衝突を黙って上書きしない。非対応APIは選択時に停止。|
|C06|Spack既定|明示+containerだけ有効。無指定・~containerは従来経路。extension導入のみで既定値/生成設定を変えない。|
|C07|通常操作|利用者にcontainer専用source/module load/別CLI/venv/パス設定を要求しない。管理者による一度のCore patchと同じホストPython環境へのinstallは区別する。|
|C08|障害分離|未導入・未選択機能は通常経路に副作用を出さない。選択した機能の欠落/失敗は明示停止。作成済み拡張workspaceを機能未導入で誤ってnativeとして消さない。|
|C09|System/Experiment分担|runtimeはSystem execution設定で一度、image/toolsはSystemのBase宣言、Base/requirements/setup.sh/artifactはExperiment、Tuneは差分。|
|C10|Container内の構築|依存構築はBase自身のPython/pip/Bashで実行。pip.pyz・host site-packages・外部installer/toolchainを注入しない。requirements/lock TEXTとGit管理setup.shおよび入力資材をmount。|
|C11|本体機能の不変|今回の移設でv0.5.2のpreparation/runtime/追加依存方針を勝手に作り直さない。不変hashまたは厳密な差分理由を残す。|
|C12|再現性|image digest/SIF hash、requirements固定、モデル識別/資材hash、setup script identityを維持。Baseのpipの記録。latest自動追従・隠れたoverride禁止。|
|C13|固定snapshot|初期化済み実験・Systemの固定記録を後の定義変更で変えない。旧v0.5.2実験/資材形式との互換性を検査。|
|C14|Workspace保護|破壊操作より前の保護、改ざん/パストラバーサル/重複resource検査を維持。単一post hookにまとめて保護を失わない。|
|C15|設定生成|Container選択時のみsoftware providerを適用しnative/helper依存を黙って捨てない。Ramble設定追加は明示的な生成境界のみ。|
|C16|全条件|matrix/zips/設定プリセット/明示値競合/繰返し/非実行repeat baseの区別を維持し各条件を具体化する。|
|C17|実行の境界|Ramble adapterとnode runtimeの既存動作・stderr分離・宣言tools・mount/起動を維持する。実Apptainer試験とtest doubleを混同しない。|
|C18|CER|実際の条件と観測をrun/attempt単位で保存し失敗phase/log/hashを維持。全Trial・再試行旧記録の非上書きを維持。|
|C19|CLI|benchpark cerの登録/help/既存CLI優先、構造検査・compare/export等の実装済み機能を維持。|
|C20|導入安全|diff生成/checkが既存checkoutを変えない。明示apply/逆適用だけで変更。非対応位置・汚れたCore・未知ファイル競合で停止。installでCoreを勝手に編集しない。|
|C21|旧機能試験|既存試験のassertを弱めて合格させない。移設に伴うimport/portの変更は理由を記録。旧新機能の差分検査を追加。|
|C22|別機能で一般性確認|非Containerの小さいpluginを同じloader経由で使える試験を行う。仮想将来機能の大量実装はしない。|
|C23|upstream検証|RIKEN固定commitとLLNLを識別しpatch適用/構文/非回帰を区別。実checkout/実Spack build/Container E2Eを未実施なら保留と明記。git apply成功を意味的互換の保証にしない。|
|C24|配布整合|source/runtime bundle/wheel/version/docsを整合させ、旧Core実装をwheelに混入させない。GitHubへ載せられるrepo/CI/ライセンス/差分を含む。|
|C25|全件レビュー|修正するたびにC01からC26まで順序通り全て再判定。未実行をPASSにしない。検査スクリプトの網羅限界を明記。|
|C26|結果の正確性|成果物と試験証跡を保存。実機未検証/自己レビューの限界を明記し、全機能無欠陥/無影響を未実証のまま断定しない。|

## 変更しない対象

v0.5.2の実行・依存構築・CERのアルゴリズムを機能基準とする。Coreを薄くするために動作を削らない。実機ログの過去PASSは今回の実機PASSとして流用しない。今回の変更は実装配置・接続契約・導入手順の整理。

## レビュー順序

1. このリストと入力ZIPのSHA-256を保存。
2. 移設案を設計して実装。
3. 全試験と全C項目をC01から再レビューし、各項目の根拠を保存。
4. FAILに修正を入れたら、前回PASSを無条件に引き継がず全順序で再実行。
5. 最終成果物を別場所へ展開して配布整合を確認。
