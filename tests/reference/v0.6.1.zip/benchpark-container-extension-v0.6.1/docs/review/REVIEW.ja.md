# v0.6.1 設計・実装レビュー総括

## 結論

`FN_apps`で確認されたnon-Spack setup compatibilityをCore patchへ追加した。変更は、upstream `setup.py`が`{spack_env_cmd}`を無条件に出力しながらSpack branch内だけで代入する場合に限り、branch直前へneutralな`spack_env_cmd = ""`を1行追加するもの。Container固有分岐ではなくpackage-manager非依存化の最小一般化であり、Spack branch本体は変更しない。

固定済みC01–C26を変更せずRound04として先頭から再レビューした。ローカル判定は25項目PASS_LOCAL、C23はv0.6.1実機E2E未実施のためPENDING-EXTERNAL。全体受入合格とは宣言しない。

## 今回の追加確認

- `FN_apps`型layoutをmodel化し、neutral defaultがexactly once追加されることを試験。
- `{spack_env_cmd}`を参照しないupstreamには余分な初期化を追加しない。
- runtime/environment/CER主要13 moduleは変更なし。
- runtime bundle check、architecture audit、全pytest 332件を修正後に再実行。
- 0.6.1.dev0 wheelをbuildし、隔離install、entry point、CER CLI、禁止installer payload非混入を検証。
- frozen compliance listのSHAは変更していない。

## 外部検証

ユーザー実機ではv0.6.0についてRIKEN/DGX Spark上の`verify_upstream.py --run`とExtension導入前後のSpack実行が確認された。しかし今回の1行compatibilityを含むv0.6.1での実checkout/Apptainer/SIF E2Eはまだ実行されていないため、C23は保留のままとする。

本レビューは自己レビューであり、未知の欠陥不在を証明しない。
