# v0.5.1 Evidence Collision 横並び監査

## 実機で確認された原因

`preflight_tools()` と `prepare_environment()` が同じ attempt 内で `base-pip-version` という同一 evidence stem を使って `python -m pip --version` を2回実行していた。`atomic_json()` は attempt evidence を上書きしないため、2回目の `.command.json` 作成で `FileExistsError` になった。

これは pip / SIF / requirements の問題ではなく、Extension 内部の evidence naming / duplicate probe の実装バグ。

## 横並び点検

| 領域 | 点検 | 対応 |
|---|---|---|
| `_capture()` command evidence | 同一 stem の再利用 | 実行前に `.command.json/.stdout.log/.stderr.log` の存在を検出して `EVIDENCE_STEM_REUSED` で停止 |
| Base pip version probe | 2重 probe | preflight 1回だけに統合し、その観測値を後段へ渡す |
| `_inspect()` / `pip check` probes | literal stem 衝突 | static architecture audit で横断検出 |
| `environment.json`, `layer-inventory.json` | attempt 固有 single-writer | 現状1箇所のみ。exclusive writeを維持 |
| `started.json`, `cer.json` | UUID attempt 固有 single-writer | 現状1箇所のみ。exclusive writeを維持 |
| concrete plan JSON | content-addressed 共有 immutable file | `atomic_json_verified()` で concurrent identical create を許容、内容差異は拒否 |
| image cache metadata | 共有 immutable file | 既存の file lock 内で生成されるため維持 |
| CLI export | ユーザー指定 output | 既存ファイル上書きを暗黙許可しないため exclusive writeを維持 |

## 不変条件

1. attempt evidence は single-writer。重複名は上書き・黙認せず、2回目のコマンド実行前に検出する。
2. content-addressed 共有 immutable file は concurrent identical publication のみ許容し、異なる内容は拒否する。
3. Base tool probe の結果は後段へ引き継ぎ、同じ事実を同じ attempt で再probeしない。
4. この修正は software boundary を変更しない。pip/Python/installerをExtensionからmountしない。
