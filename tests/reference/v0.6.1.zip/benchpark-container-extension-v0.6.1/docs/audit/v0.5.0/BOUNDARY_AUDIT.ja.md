# v0.5.0 横並び境界監査

目的: 実機で露出した個別エラーを潰すのではなく、「Common Base内のsoftware environmentはCommon Base自身のtoolだけで構築する」という要求をproduction path全体へ適用する。

## 監査結果

| 領域 | 確認したこと | v0.5.0 |
|---|---|---|
| Container mount | runtimeがbindするのはattempt scratch、`/bpce/inputs`、明示artifactのみ。Extension resource rootをbindしない | PASS |
| Python interpreter | Base releaseが宣言したPythonをContainer内preflightで解決し、その同じ値をpip/probe/benchmarkへ使用 | PASS |
| pip | `pip = [python, '-m', 'pip']`のみ。pip.pyz/別pip/upgrade/bootstrapなし | PASS |
| pip install semantics | Extension側`--no-deps`/`--target`/`--ignore-installed`/`--isolated`/inject constraintなし。`--prefix`はimmutable SIF外の書込先指定のみ | PASS |
| Python software inputs | requirements/lock/constraint textのみsnapshot。local wheel/sdist/path/VCS/direct-reference payloadはreject | PASS |
| extra commands | Git管理setup scriptをBase BashでContainer内実行。`BPCE_PREFIX=/bpce/tools` | PASS |
| Base preservation | private Python layerでBase同名distributionを検出したら停止 | PASS |
| dependency check | install前後を同一Base pipで実行。pip version固有diagnostic regexなし | PASS |
| host-native builder | `NativeRuntime`/`native_case`/native torch preparation helperを現行test/toolsから削除 | PASS |
| Application | benchmark Pythonは`{bpce_python}`→実行時`BPCE_BASE_PYTHON`契約を使用 | PASS |
| host worker | runtime.pyzはworkspace上のhost worker。Containerへmountしない | PASS |
| Core | generic extension API/supportのみ。concrete Container runtime/pip importなし | PASS |
| distribution | wheel内にpip.pyz/installer/environment.py/sitecustomize/nested Python package payloadなし | PASS |

## Allowed internal constants

`/bpce`, `/bpce/inputs`, `/bpce/python`, `/bpce/tools`, `/bpce/work`はExtension private ABIであり、site固有Python/Bash pathのhard-codeとは区別する。

## 実機未確認

- RIKEN実checkout + v0.5.0 Core patch
- user supplied `pytorch-bench-1.0.sif` + Apptainer 1.5.0
- GPU passthrough
- 実model/LLM requirements

したがって本監査は境界違反の回帰検出であり、実機E2E成功の代替ではない。
