# Benchpark Container Extension v0.6.1 — 小さいCore接続と外部実装

## 1. 今回の目的

既存のSpackベースBenchparkへ、Container/CERを後付けする。Coreを薄くする目的は**upstream追従コストの低減**であって、見かけの行数最小化ではない。v0.5.2の機能を落とさず、Coreへ置かれていた機能・保存・設定合成を外部へ移す。

現在の位置付けはリファクタリング開発版。ローカルでの設計検査・単体・差分検査と、実RIKEN/LLNL/Apptainer E2Eを区別する。後者は今回の環境では未実施。

## 2. 配置

```text
既存Benchpark
  lib/benchpark/plugins.py        # 標準ライブラリだけのoptional loader / dispatch
  既存6ファイルの処理境界         # データの抽出、native処理、結果の適用
                 |
                 | entry point / versioned port
                 v
GitHub: benchpark-container-extension
  benchpark_integration/
    api.py                       # 既存feature protocol。Coreから移動
    discovery.py                 # feature/tune/command descriptorを発見
    hooks.py                     # 外部側のlifecycle coordinator
    support/options.py           # native指定と外部指定の分離・検証
    support/generation.py        # software provider、追加設定の合成
    support/io.py                # System snapshot / immutable publication
    support/storage.py           # 固定設定、staging、削除前guard
  benchpark_container/           # Container/requirements/setup.sh/Ramble/CER
  benchpark_tuning/              # Baseに対する固定差分プリセット
```

Coreには`extension_api.py`、`extensions.py`、`extension_support/*`を置かない。互換import名をCoreに残して実装を隠す方法も採らない。

## 3. Coreに残す役割と残さない役割

**残す**: installed metadataの列挙、選択されたproviderのload、API番号の確認、dispatch、既存CLIへの追加登録、保存済みowner名によるrouting。

**残さない**: Container選択、Tune解釈、requirements解釈、software providerの調停、資材のコピー、snapshot作成、Ramble用設定の合成、CER生成・保存、コンテナ起動。

`owners_at()`が読む`.benchpark-extensions/manifest.json`は、機能を外したときにも旧実験を誤ってnativeとして削除しないための**汎用routing marker**。読むのはowner名のみ。Coreでhash検証・stage・copy・記録作成を行わない。既存v0.5.2の保存形式を維持するため同じパスを使う。

## 4. Native concretizerを書き換えない

v0.5.2はnative concretizer内部の複数のschema参照を差し替えていた。v0.6.1は`ExperimentSpec.concretize()`の入口と出口で扱う。

```text
明示指定
  -> 選択名からproviderを特定
  -> 外部側でfeature option/Tuneを検証
  -> native値を既存ConcreteExperimentSpecへ渡す
  -> 既存native検証をそのまま実行
  -> 検証済みの外部optionとplain metadataを結果へ付加
```

`ConcreteSpec._concretize()`のアルゴリズムはAST同一性を検査する。既存Variant class registryを変更せず、モデル・実験間で外部optionが漏れない。外部featureの型検証は外部側で実施する。native fieldはnativeのまま検証する。

**制約**: nativeのconditional variant規則が、後から付加される外部featureの値へ依存する使い方はこのcontractの対象外。v0.5.2のContainer/Tune利用経路はその使い方をしていない。外部optionをnative classに重複宣言して乗っ取る方式ではなく、nativeの同名optionはnativeとして優先する。

未選択時はnative concretizerへ直接進み、Container実装を読み込まない。明示`~container`はfalseとして保持し、Baseを自動選択しない。

## 5. 小さい契約と限定された操作

Coreから生の`Spec`、`Experiment`、`System`、repository objectを渡さない。渡すのは名前、variant値、既定値、宣言のdict、source path等。Container/Tune featureへは既存のread-only contextで渡す。

生成とworkspaceには順序依存があるため、無理に単一の「生成後hook」へしない。以下は明示した**限定port**であり、Benchpark内部全体を渡すものではない。

|port|外部側から利用できるもの|目的|
|---|---|---|
|generation|native software section生成の0引数callable、helper software sectionの0引数callable|選択されたsoftware providerがないときだけnative生成。helper依存を勝手に捨てない|
|workspace|src/dst、native copy関数、include predicate、templateのsrc/dst|native fallbackと同じファイル選択を維持し、拡張資材だけsnapshotから配置|
|CLI|argparseのsubparser・command handler|既存CLIと同じparser上でサブコマンドを登録|

これらはPython内のtrusted plugin間の契約であり、悪意あるpluginのsandboxではない。callbackを`__self__`等から逆引きしてCore内部へ介入することは禁止。実装中にそのような参照はないことを確認する。descriptor、policy、状態の相互互換は外部packageの責任。

## 6. Hook一覧

|event|Core側の位置|渡すもの／戻すもの|
|---|---|---|
|request|ExperimentSpec.concretizeの前後|明示native値・宣言metadata -> native値・検証済み外部値・plain状態|
|system_saved|system.write_system_dict後|宣言settings、保存先 -> snapshot（外部で保存）|
|experiment_resolve|System紐付け後、ramble.yaml生成前|System保存先・実験宣言・確定値 -> contribution群|
|generation|compute_ramble_dict|contribution -> generation port。nativeの他メソッドは変更しない|
|experiment_saved|ramble.yaml保存後|生成先、宣言済み資材 -> 固定snapshot（外部で保存）|
|workspace|削除判定前、stage、template配置|owner routing -> lifecycle port。削除前guardを必ず先に行う|
|CLI|実際の組込みcommand登録後／top help|metadata、選択したdescriptor|

「5個のhookだけで何でもできる」とは扱わない。必要なタイミングを維持することを優先する。名前と引数、どの順序で呼ばれるかを`PLUGIN_API.ja.md`に記載する。

## 7. 複数pluginと故障の扱い

Coreの`benchpark.lifecycle.v1`登録は、機能名からlifecycle coordinatorを選ぶ。ContainerとTuneは同じ外部coordinatorへaliasし、そこで既存のfeature/preparer descriptorを合成する。v0.5.2の複数feature・衝突検出を維持する。

独立したcoordinatorが同じ処理へ同時に選択された場合は拒否する。暗黙の優先順位・last-winsは導入しない。他の独立したreport provider、CLI pluginを同じloaderで使う試験を追加している。任意の第三者coordinator同士を無条件に同時使用できるという保証ではない。

未導入・未選択: native機能を継続。選択されたpluginが壊れている/未導入: 明示的なエラー。owner markerが残る拡張workspaceはpluginを外してもnativeの削除対象へ戻さない。

## 8. 要求された操作と実行境界は変更しない

- Spackが既定。利用者はContainerを使う実験だけ`+container`を付ける。
- 管理者は一度、Core patchを確認・適用し、同じホストPythonへ外部packageを導入する。
- 利用者に拡張専用のsource/module load/venv/path設定を要求しない。
- `system.py`: runtime、Common Base群、宣言tools、artifact root。
- `experiment.py`: Base、requirements、Git管理setup.sh、mount要求、Model/Workload。
- `tuning/*.yaml`: 既存の固定差分。
- BaseのPython/pip/Bashを使う。独自pip/installer/host site-packagesをコンテナへ持ち込まない。
- requirements/lock TEXT、setup.sh、宣言済みartifactをmount。
- 成功・失敗・再試行をCERへ記録し、過去attemptを上書きしない。

Docker、複数node/MPI、適応探索器は元々v0.5.2の実装範囲外。今回の「機能維持」を口実に実装済みとは記載しない。

## 9. 追従性の評価

良い指標は「Core新規行数が少ない」だけではない。今回、native concretizerの内部schema差替えをやめ、public boundaryへデータ変換を移したため、既存ファイルへの追加行はv0.5.2より増える。その代わり、Core新規8ファイル778行を1ファイルへ減らし、内部passへの介入を除去した。

差分件数・各関数・行数は`results/core-diff/metrics.json`を参照。行数を少なく見せるために1行へ複雑な処理を詰め込む、spec全体をpluginに渡す、monkey patchで隠すことはしない。

upstreamの処理順序や宣言の公開形が変わればport側も見直しが必要。`git apply --check`はテキスト適用確認であり、意味的互換性の証明ではない。API contract testと実checkoutの非回帰を併用する。

## 10. 妥当性と限界

BenchparkのSystem（供給環境）・Experiment（測定条件）・Ramble（実行設定）の役割を維持している。Python entry pointsによる外部発見、差分patchの明示適用・逆適用は標準の機構を利用する。

局所的な設計判断: 情報隠蔽と変更影響範囲の限定、機能差分検証、plugin未選択時の後方互換により、この用途で保守負担を減らす案として合理的。万能のplugin基盤でも、ゼロメンテナンスでもない。

レビューは自己レビュー。実機・複数upstream revision試験は環境不足で保留。静的検査は特定ルールの回帰検出であり、「全問題がない」という証明ではない。

参考（公開ソースと設計判断を区別）:
- Benchpark公式のSystem/Benchmark/Experimentの分担: https://software.llnl.gov/benchpark/
- RIKEN固定版のnative concretizer: https://raw.githubusercontent.com/RIKEN-RCCS/benchpark/30d698dcab53c2d79e229b45bfcd0defcae33b72/lib/benchpark/spec.py
- Python distribution entry points: https://packaging.python.org/en/latest/specifications/entry-points/
- importlib.metadata: https://docs.python.org/3/library/importlib.metadata.html
- git apply --check/--reverse: https://git-scm.com/docs/git-apply
