# v0.6.1.dev0 検証結果と限界

## 判定

今回の変更は`FN_apps`のnon-Spack setup compatibilityをCore patch generatorへ追加するもの。固定済みC01–C26をRound04で全件再確認し、**25項目PASS_LOCAL、C23 PENDING-EXTERNAL**。v0.6.1の実機E2Eはまだ未実施なので全体合格とはしない。

|実施|結果|
|---|---|
|runtime bundle|PASS|
|architecture audit|PASS、31 Python files、0 issues|
|全pytest|332 passed / 0 failed / 0 skipped|
|FN_apps compatibility回帰|neutral `spack_env_cmd = ""`をexactly once追加|
|非該当upstream回帰|`spack_env_cmd`参照がなければ追加しない|
|実wheel|`0.6.1.dev0`をbuild、隔離install・entry point・CER CLI確認|
|機能本体|runtime/environment/CER主要13 moduleは基準から変更なし|
|全件レビュー|`results/reviews/04/REVIEW.ja.md`|

## 変更の意味

Spack branchを変更せず、non-Spack package managerのとき未定義の`spack_env_cmd`がsetup.sh生成時に参照されないようneutral defaultを置く。`if container:`のようなContainer固有分岐はCoreに追加しない。

## 未検証

v0.6.1を実際のRIKEN/FN_apps checkoutへ適用した`benchpark setup`、実Apptainer/SIF、GPU E2Eは未実施。ユーザーによるv0.6.0実機結果をv0.6.1の合格として流用しない。
