# 04 全項目レビュー

外部E2Eは未実施。PASS_LOCALは実機合格を意味しない。

|ID|判定|根拠|
|---|---|---|
|C01|PASS_LOCAL|v0.5.2の機能試験を維持し、新規含む全332件成功。runtime/environment/CER主要moduleは基準版と同等で、今回の変更はCore patch生成時のnon-Spack neutral defaultだけ。|
|C02|PASS_LOCAL|新規Coreはplugins.py 120行/標準ライブラリのみ。外部integration packageがoptions/generation/storage/APIを保有。tests/test_small_core_seam.pyとstatic_checks。|
|C03|PASS_LOCAL|native concretizer/Experiment境界の既存AST試験を維持。FN_apps型setup.pyではSpack branchを変更せず、その直前にneutralなspack_env_cmd空値を1行だけ追加。Container固有条件分岐は追加しない。|
|C04|PASS_LOCAL|Coreから宣言dict/値/pathを渡し、生Spec/System/Experimentは渡さない。generation/native-helper callback、workspace copy/predicate、argparseだけを文書化した限定portとする。|
|C05|PASS_LOCAL|Core API1/外部feature API2を区別。重複名/API不一致/独立coordinator衝突/同名native優先をテスト。複数featureは明示coordinator経由。|
|C06|PASS_LOCAL|無指定と~containerはnative/Spack既定を維持。今回のcompatibility初期化はSpack branchの処理内容を変更せず、non-Spack時のみ未定義参照を防ぐ。全332件成功。|
|C07|PASS_LOCAL|利用手順は管理者1回のCore patch+同一host Pythonへのextension installで不変。FN_apps compatibilityも同じCore patchへ含め、利用者に追加操作を要求しない。|
|C08|PASS_LOCAL|未選択featureは従来経路に副作用なし。non-Spack neutral defaultはupstreamがsetup.shでspack_env_cmdを無条件参照するlayoutにだけpatch生成時に追加し、provider未選択時のSpack経路は同じ。|
|C09|PASS_LOCAL|examples System/Experimentの宣言形式とroleは基準版から変更なし。新brokerはSystem snapshotとExperiment論理要求を受け取る。|
|C10|PASS_LOCAL|Base Python/pip/Bashによる構築経路とresourcesは保持。新しいloader/brokerはContainerへmountしない。独自pip/installer/venv禁止の既存auditとwheel境界検査。|
|C11|PASS_LOCAL|preparation/runtime/contracts/artifacts/util/provenance/requirements/reproducibility/reproducibility_rules/ramble_adapter/CER3ファイルはbyte同一。resolver/plugin/cliはAPI import先のみ変更。|
|C12|PASS_LOCAL|既存pin/hash/model/artifact/setup script validationと負例を保持。prepared requestの入力不変、明示値/Tune競合、再現性validator試験。|
|C13|PASS_LOCAL|System snapshotとmanifest schema3/plan/資材形式は維持。旧/新の固定入力snapshot bytes差分が一致。旧worker資材は再書換えしない。|
|C14|PASS_LOCAL|workspace guardは削除前。missing providerでもowner routingがfail-closed。source containment/入力改ざん/duplicate資材/既存出力拒否試験は保持。|
|C15|PASS_LOCAL|native software生成は遅延callbackで1境界のみ。software providerによる二重担当/既存helper requirementsの破棄を拒否。既存値/variable/env/modifier collision testsを保持。|
|C16|PASS_LOCAL|matrix/zips/固定Tune/CLI conflict/repeat base除外/試行IDは既存機構を保持し旧試験成功。node adapter本体は変更なし。|
|C17|PASS_LOCAL|runtime/bundle/moduleのhashとstderr/argv/mount契約を確認。テストdoubleは実Container試験と明記して区別。Apptainer本体は実行していない。|
|C18|PASS_LOCAL|CER lifecycle/failure phase/全Trial/immutable evidence/並行作成/別attempt/非上書きの旧試験を保持。記録実装は不変。|
|C19|PASS_LOCAL|実wheelを隔離installし新Core registryからcer --help、validate/exportの表示を確認。元のCLI試験も保持。native command名を実parser登録から優先。|
|C20|PASS_LOCAL|patch生成/check/apply/reverseの既存試験に加え、FN_apps型layoutでspack_env_cmd neutral defaultがexactly once追加される回帰試験と、参照しないupstreamには追加しない試験を追加。全test成功。|
|C21|PASS_LOCAL|既存test関数を削除/弱体化せず、FN_apps non-Spack compatibilityの正負2試験を追加。skip/xfailなし。|
|C22|PASS_LOCAL|独立non-container report provider、CLI provider、Containerとobserve featureの組合せを同じ新loaderでテスト。coordinator間の無制限合成は保証しない。|
|C23|PENDING-EXTERNAL|ユーザー実機ではv0.6.0のRIKEN/DGX Sparkでverify_upstream E2EとSpack前後経路が確認されたが、v0.6.1のこの変更を含む実checkout/Container E2Eはまだ未実施。よってPENDING-EXTERNALを維持。|
|C24|PASS_LOCAL|0.6.1.dev0へversion整合。runtime bundle/audit/full pytest 332件、実wheel buildと隔離install/entry point/CER CLI検証を実施。COMPLIANCE checklistは固定のまま。|
|C25|PASS_LOCAL|今回の修正後、固定COMPLIANCE C01-C26をRound04として先頭から全件再判定。以前のPASSを無条件継承せず、review harnessがbundle/audit/full pytestを再実行する。|
|C26|PASS_LOCAL|今回のローカル証拠と外部未検証を分離。v0.6.1は実機E2E未実施のため全体合格とは宣言しない。wheel検証と332件のローカル試験を記録。|
