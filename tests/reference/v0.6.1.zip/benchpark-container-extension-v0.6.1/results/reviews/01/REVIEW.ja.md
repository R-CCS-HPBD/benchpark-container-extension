# 01 全項目レビュー

外部E2Eは未実施。PASS_LOCALは実機合格を意味しない。

|ID|判定|根拠|
|---|---|---|
|C01|FAIL|旧289試験中287成功、2失敗。既存動作として匿名specの例外が変化。機能維持未達。|
|C02|FAIL|Core新規1ファイル120行。API/機能合成/stagingは外部へ移動。Core新規は標準ライブラリのみ。|
|C03|FAIL|ConcreteSpec._concretizeは変更しない。元のspec入口/出口へ接続。ただし匿名specの先行class取得を是正必要。|
|C04|FAIL|生のSystem/Experiment/Specは外部へ渡さない。生成時のnative/helper section callableとworkspaceのcopy/predicateが限定port。明文化は未完。|
|C05|FAIL|feature/api2を外部で維持。Core lifecycle API1。異なるcoordinator共存は明示エラー。新portの競合試験が不足。|
|C06|FAIL|既存明示+container/無指定/~container試験は成功。匿名spec失敗あり。|
|C07|FAIL|entry points経由の自動発見と通常CLI維持。旧READMEが残っているので手順未整合。|
|C08|FAIL|未選択feature未load試験成功。provider欠落とworkspace破壊前guardの新loader試験を追加必要。|
|C09|FAIL|System/Experiment宣言APIは維持。examplesソース未変更。|
|C10|FAIL|preparation.py/runtime.pyおよびnode資材は移設前と同一。Base内pip境界は既存試験で成功。|
|C11|FAIL|実行/preparation等13モジュールのSHA一致。resolver/plugin/cliはAPI import先の変更のみ（version除外）。|
|C12|FAIL|既存再現性validatorの試験を残し通過。新option validatorの負例追加が必要。|
|C13|FAIL|固定snapshotファイル形式を変更せず。旧版snapshotを新版で読み込む差分試験は未追加。|
|C14|FAIL|旧workspace保護の全試験通過。新Coreのowner routing guard接続は追加検証が必要。|
|C15|FAIL|既存generation試験は最後の旧属性名を読む1assertのみ失敗。生成内容はそこまで同等。helper供給の機能を維持。|
|C16|FAIL|既存matrix/zips/repeat/Tune試験通過。Core request metadata名の変更を記録する必要。|
|C17|FAIL|Apptainer側実行コードは未変更。ローカルのtest doubleで保存系試験は通過。実SIF E2Eは未実施。|
|C18|FAIL|CER実行コードは未変更。既存serialization/retry/append-only試験は通過。|
|C19|FAIL|wheel隔離導入・実CLI registry試験は通過。旧CLI supportは互換用として外部に残存。|
|C20|FAIL|patchの適用/逆適用は旧fixtureで通過。実checkout未実施。patch generatorのCLI安全操作を追加検証必要。|
|C21|FAIL|289件の機能assertを維持。private import/metadata/port入力のみ移行。2失敗を修正必要。|
|C22|FAIL|非Containerの同一broker feature試験が通過。他の独立providerのロード/CLI試験を追加必要。|
|C23|PENDING-EXTERNAL|GitHub cloneはDNSエラー。Apptainerなし。ローカルfixtureの適用は本物のupstream E2Eではない。|
|C24|FAIL|wheel試験は成功。README/CI/設計書/summaryが旧Core配置の説明のまま。リリース整合未完。|
|C25|FAIL|C01-C26をこの順番で再評価。初回結果の失敗を保存してから次修正へ進む。|
|C26|FAIL|実機成功は主張していない。最終報告と未検証項目の整備が未完。|
