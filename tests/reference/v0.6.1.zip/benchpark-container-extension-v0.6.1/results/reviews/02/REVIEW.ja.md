# 02 全項目レビュー

外部E2Eは未実施。PASS_LOCALは実機合格を意味しない。

|ID|判定|根拠|
|---|---|---|
|C01|PASS_LOCAL|旧289件の機能試験を維持し、新規含む328件成功。tests/test_reference_equivalence.pyで旧/新21 requestとsnapshotを差分比較。13主要moduleはbyte同一。|
|C02|PASS_LOCAL|新規Coreはplugins.py 120行/標準ライブラリのみ。外部integration packageがoptions/generation/storage/APIを保有。tests/test_small_core_seam.pyとstatic_checks。|
|C03|PASS_LOCAL|ConcreteSpec全methodとcompute_ramble_dict以外のExperiment methodのASTを保持。匿名spec回帰を修正。6ファイル境界へ差分、class schema/継承/既存アルゴリズムは書換えない。|
|C04|PASS_LOCAL|Coreから宣言dict/値/pathを渡し、生Spec/System/Experimentは渡さない。generation/native-helper callback、workspace copy/predicate、argparseだけを文書化した限定portとする。|
|C05|PASS_LOCAL|Core API1/外部feature API2を区別。重複名/API不一致/独立coordinator衝突/同名native優先をテスト。複数featureは明示coordinator経由。|
|C06|PASS_LOCAL|無指定と~containerはnative、Spack既定。global class schema変更なし。旧/新request差分と連続+container/native初期化の試験。|
|C07|PASS_LOCAL|管理者1回のdiff適用+同じhost Pythonへのinstallで登録。一般利用者は既存CLIに+containerを付けるだけ。READMEに管理者/利用者の境界と通常setupを明記。|
|C08|PASS_LOCAL|未選択feature故障をnativeに伝播しない。missing-providerのowner markerをCoreが先に読んで停止。壊れたmarker、dangling symlink、二重owner等を検証。|
|C09|PASS_LOCAL|examples System/Experimentの宣言形式とroleは基準版から変更なし。新brokerはSystem snapshotとExperiment論理要求を受け取る。|
|C10|PASS_LOCAL|Base Python/pip/Bashによる構築経路とresourcesは保持。新しいloader/brokerはContainerへmountしない。独自pip/installer/venv禁止の既存auditとwheel境界検査。|
|C11|PASS_LOCAL|preparation/runtime/contracts/artifacts/util/provenance/requirements/reproducibility/reproducibility_rules/ramble_adapter/CER3ファイルはbyte同一。resolver/plugin/cliはAPI import先のみ変更。|
|C12|PASS_LOCAL|既存pin/hash/model/artifact/setup script validationと負例を保持。prepared requestの入力不変、明示値/Tune競合、再現性validator試験。|
|C13|PASS_LOCAL|System snapshotとmanifest schema3/plan/資材形式は維持。旧/新の固定入力snapshot bytes差分が一致。旧worker資材は再書換えしない。|
|C14|PASS_LOCAL|workspace guardは削除前。missing providerでもowner routingがfail-closed。source containment/入力改ざん/duplicate資材/既存出力拒否試験は保持。|
|C15|PASS_LOCAL|native software生成は遅延callbackで1境界のみ。software providerによる二重担当/既存helper requirementsの破棄を拒否。既存値/variable/env/modifier collision testsを保持。|
|C16|PASS_LOCAL|matrix/zips/固定Tune/CLI conflict/repeat base除外/試行IDは既存機構を保持し旧試験成功。node adapter本体は変更なし。|
|C17|PASS_LOCAL|runtime/bundle/moduleのhashとstderr/argv/mount契約を確認。テストdoubleは実Container試験と明記して区別。Apptainer本体は実行していない。|
|C18|PASS_LOCAL|CER lifecycle/failure phase/全Trial/immutable evidence/並行作成/別attempt/非上書きの旧試験を保持。記録実装は不変。|
|C19|PASS_LOCAL|実wheelを隔離installし新Core registryからcer --help、validate/exportの表示を確認。元のCLI試験も保持。native command名を実parser登録から優先。|
|C20|PASS_LOCAL|実git fixtureで差分生成がcheckout無変更、明示apply/逆適用、dirty Core拒否、未知anchor拒否、既存review出力拒否、checkout内出力拒否を確認。非Coreの未commit資材も保持。|
|C21|PASS_LOCAL|全旧test関数を維持。private API/object identity assertionの変更はTEST_MIGRATION.ja.mdに列挙し、対応する観測値を旧新プロセス差分で確認。skip/xfailによる回避なし。|
|C22|PASS_LOCAL|独立non-container report provider、CLI provider、Containerとobserve featureの組合せを同じ新loaderでテスト。coordinator間の無制限合成は保証しない。|
|C23|PENDING-EXTERNAL|RIKENの4原本ファイルhashはユーザー報告と一致するfixtureを使用。ただし実checkout全体ではない。GitHub clone通信はDNS失敗、Apptainer/Dockerなし。LLNL/RIKEN/実Spack/実SIF/GPUは未実施。|
|C24|PASS_LOCAL|wheel構築・隔離install・entry point・runtime bundle・禁止payload非混入・sdistに基準archive/Core patch資材同梱を確認。README/設計/API/CHANGELOGは0.6.0.dev0へ整合。|
|C25|PASS_LOCAL|COMPLIANCEを実装前に固定しSHA維持。Round01のFAILを保持。Round02はC01からC26を全て再判定。harnessにもtimeout/test failure時に全件FAIL/保留を残す試験を追加。|
|C26|PASS_LOCAL|PASS_LOCALとPENDING-EXTERNALを分離。初回287pass2fail、基準版289pass、新版328passを別ログ化。自己レビューであること、性能/実機無欠陥を証明しない旨を明記。|
