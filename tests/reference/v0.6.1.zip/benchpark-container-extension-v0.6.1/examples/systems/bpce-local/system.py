# SPDX-License-Identifier: Apache-2.0
"""Single-process test System; immutable Base SIF supplied at system init."""
from pathlib import Path
import sys
from benchpark.directives import variant
from benchpark.system import System


class BpceLocal(System):
    variant('base_sif', default='none', description='Absolute path to a Common Base SIF containing Python, pip, Bash and torch (no venv requirement)')
    variant('image_cache', default='~/.cache/benchpark/images', description='Absolute image cache path')
    variant('gpu_passthrough', default='none', values=('none','nvidia','amd'), description='Apptainer device support, independently validated')
    variant('base_python', default='python3', description='Python executable supplied by this Base')
    variant('base_shell', default='bash', description='Bash executable supplied by this Base')
    variant('runtime_executable', default='apptainer', description='Site Apptainer executable')
    variant('worker_python', default=sys.executable, description='Site host Python for the stdlib-only worker')
    id_to_resources={'default':{'sys_cores_per_node':1,'scheduler':'mpi'}}

    def __init__(self,spec):
        super().__init__(spec)
        self.sys_cores_per_node=1
        # Benchpark's mpi allocation mode also handles non-MPI commands.
        # The example application deliberately does not invoke mpirun.
        self.scheduler='mpi'
        sif=Path(spec.variants['base_sif'][0]).expanduser()
        if not sif.is_absolute() or not sif.is_file():
            raise ValueError('Set base_sif=/absolute/path/base.sif at system init')
        self.extension_settings={'container':{
            'schema_version':2,
            'execution':{'runtime':'apptainer','executable':spec.variants['runtime_executable'][0],
                         'worker_python':spec.variants['worker_python'][0],'image_cache':str(Path(spec.variants['image_cache'][0]).expanduser().resolve()),
                         'gpu':spec.variants['gpu_passthrough'][0]},
            'base_images':{'pytorch-base':{'default':'release-a','releases':{
                'release-a':{'uri':sif.as_uri(),'origin':'operator-supplied Common Base SIF',
                             'tools':{'python':spec.variants['base_python'][0], 'shell':spec.variants['base_shell'][0]}}}}},
            'artifact_roots':{}}}

    def compute_software_section(self):
        return {'software':{'packages':{}}}
