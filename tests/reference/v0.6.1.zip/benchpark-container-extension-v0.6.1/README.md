# Benchpark Container Extension — 0.6.1.dev0

**既存のSpackベースBenchparkへ、小さい汎用Core patchと外部Python packageでContainer/CERを後付けする開発版です。**

v0.5.2の実行・追加依存構築・CER本体は維持し、Coreに置いていたintegration frameworkを外部packageへ移しました。新規Coreは**1ファイルの標準ライブラリloader**です。必要な6ファイルの処理境界にはhookが残ります。「pip installだけで未変更Benchparkに使える」状態ではありません。

## 1. 変えない利用方法

```bash
# 通常のSpack既定経路
benchpark experiment init <initialized-system> '<benchmark>'

# 同じ操作でContainerを明示選択
benchpark experiment init <initialized-system> '<benchmark> +container'

benchpark setup <initialized-experiment> <new-runs-directory>
# 続いて従来どおり、生成済みsetup.shとRambleを使用する。
```

System管理者がCommon Base image/runtime/toolsを定義し、Experiment開発者がBaseパラメータ・requirements・setup.sh・mountを定義します。**既存の全experimentが無設定でコンテナ対応になるのではありません。** 対応定義を持つexperimentで上記を使います。一般利用者に拡張専用のsource/module load/PYTHONPATH/venvを要求しません。

## 2. 境界

```text
Benchpark Core: plugins.py + lifecycle/CLI hooks
       ↓ データと限定されたport
外部: benchpark_integration（設定解決、Tune、snapshot、stage、生成）
      benchpark_container（Base、requirements、setup.sh、Ramble、CER）
```

requirements/lock/constraint TEXTとGit管理setup.sh、宣言済みのmodel/dataset/script等をmountし、**Common Base自身のPython/pip/Bash**を使用します。独自pip、venv bootstrap、host site-packagesは持ち込みません。今回この実行方式は変更していません。

詳細：[設計](docs/ARCHITECTURE.ja.md) / [小さいCore API](docs/PLUGIN_API.ja.md) / [実行境界（v0.5.2から維持）](docs/history/v0.5.2/EXECUTION_BOUNDARY.ja.md)

## 3. 管理者による一度の導入（同じ既存checkoutへ）

本番導入前に既存環境のバックアップと、対象revisionの非回帰確認を行ってください。以下は管理者の導入操作で、毎回の利用者操作ではありません。

```bash
# すべて実際の絶対パスへ置換する
BP=/absolute/path/to/existing-benchpark
EXT=/absolute/path/to/benchpark-container-extension
PY=/absolute/path/to/benchpark-host-python
PATCH=/absolute/path/outside-benchpark/benchpark-plugin-v1.patch

# データ収集・差分生成のみ。既存checkoutを変更しない。
"$PY" "$EXT/tools/patch_core.py" "$BP" --output "$PATCH"
git -C "$BP" apply --stat "$PATCH"
git -C "$BP" apply --check "$PATCH"

# 差分を確認して承認した後に適用。同じcheckoutを使う。
git -C "$BP" apply "$PATCH"

# Benchparkが実際に使用するホストPython環境へ導入。
"$PY" -m pip install "$EXT"
```

GitHubへ置くときも同じです。release/commitを固定して取得した外部repoを`EXT`として使います。取得先owner/URLを勝手に仮定しません。`pip install`はCoreを書き換えません。

patch生成ツールは、未commitのCore変更・未知の接続位置・新規ファイルの同名衝突では停止します。Core以外の既存system/experiment資材は変更しません。出力patchとmetadataを上書きせず、**既存checkoutの外**に作成します。

**v0.5.2の旧Core patch適用済み環境へ重ねて適用しないでください。** 保存した旧patchを`git apply --reverse --check`で確認してから逆適用し、native Coreへ戻した後、新しい差分を作成します。旧patchや適用前状態が不明なら停止して差分を確認し、`git reset --hard`や未追跡ファイルの一括削除で済ませないでください。既存run、SIF、結果は削除しません。

取り消しは外部機能を使うjobが終了した後、保存した新patchへ`git apply --reverse --check`、続いて`git apply --reverse`を使います。拡張実験はproviderなしで実行不可ですが、失敗を黙ってnative扱いにしません。

## 4. ローカル開発試験

```bash
"$PY" -m pip install -e "$EXT[test]"
cd "$EXT"
"$PY" tools/build_runtime.py --check
"$PY" tools/audit_architecture.py
"$PY" -m pytest -q
```

`[test]`のinstallは管理者/開発者向けです。Common Base内のPython/pipとは別です。

## 5. 実RIKEN/LLNLの検証（未実施項目）

まず対象Benchparkのrequirementsを同じホストPythonに入れます。検証対象はcleanなupstream sourceを使います。**このスクリプトは検証用cloneにpatchするもので、本番checkoutへのinstall操作の代替ではありません。**

```bash
cd "$EXT"
OUT=/absolute/path/to/new-validation-output
"$PY" tools/verify_upstream.py /absolute/path/to/clean-benchpark \
  --output "$OUT" \
  --base-sif /absolute/path/to/existing-base.sif \
  --run
```

既存`OUT`は拒否します。過去のテスト結果は削除しません。成功時の結果は`$OUT/report.json`です。`--base-sif`なしは生成の一部、`--run`なしは実コンテナ未実行です。Spack default設定同等性はSpack build全体の合格を意味しません。

RIKEN参照revisionは`30d698dcab53c2d79e229b45bfcd0defcae33b72`。LLNLは試験する40桁commitを別途明示します。ローカルunitにはラベル付きupstream-like fixtureを使い、実checkout試験と混同しません。GitHub ActionsにはPython 3.10–3.13のunitジョブと、commit指定の実upstream検証ジョブを同梱していますが、この成果物作成時にそれらのCIは実行していません。

## 6. 厳格レビューの記録

最初に固定した26項目を変更せず、各修正ラウンドで**C01からC26まで全て**再判定しています。失敗したラウンドも残しています。

- [遵守リスト](docs/review/COMPLIANCE.ja.md)
- [初回レビュー（不合格）](results/reviews/01/REVIEW.ja.md)
- [試験移設の説明](docs/review/TEST_MIGRATION.ja.md)
- [最終テスト報告](results/TEST_REPORT.ja.md)
- `tools/review_all.py --round <新しい番号> --notes <全26項目のレビューJSON>`で全件を再実行。

`PASS_LOCAL`は確認した静的/単体/差分/配布範囲の判定です。**実Apptainer、ユーザーのSIF、GPU、実RIKEN/LLNLでのv0.6.1 E2Eは未実施（C23は保留）**です。旧v0.5.2の実機合格を新しいCore接続の合格として流用していません。Docker、multi-node MPI、自動探索器は今回の追加対象ではありません。


## v0.6.1 compatibility note

Core patch includes a neutral `spack_env_cmd = ""` initialization only when required by the upstream layout.
