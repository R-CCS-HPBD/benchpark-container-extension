# 0.6.1.dev0 — Non-Spack setup compatibility

- Core patch now initializes `spack_env_cmd` to an empty command when an upstream `setup.py` unconditionally emits that variable but defines it only inside the Spack branch.
- The change is generic to non-Spack package-manager setup; it does not add Container-specific branching to Benchpark Core.
- Native Spack behavior remains unchanged. A regression test models the `FN_apps` layout and checks that the compatibility initialization is added exactly once.
- The frozen C01–C26 compliance checklist is unchanged and is re-run from C01 after this modification.

# 0.6.0.dev0 — Thin Core lifecycle seam / feature-preserving relocation

- Freeze the 26-item checklist before implementation; retain full ordered review rounds, including failures.
- Replace eight new Core modules with one stdlib-only `benchpark.plugins` loader.
- Move API descriptors, option/Tune processing, contributions, snapshots and workspace staging into the external `benchpark_integration` package.
- Keep native `ConcreteSpec` algorithms unchanged; validate extension options in the external broker and feed native fields through the native concretizer.
- Preserve runtime/preparation/CER algorithms and resource boundary byte-for-byte relative to v0.5.2, except host import paths and release identity.
- Preserve guards before destructive workspace operations, missing-provider routing, matrix/repeat/Tune behaviour and CER CLI.
- Add old/new request+snapshot differential tests and independent generic-plugin tests. Preserve old test functions; document assertion/port changes.
- Patch review output is exclusive and outside the target checkout. Non-Core local assets are preserved. Stale installed integration modules are checked before upstream validation.
- Known evidence limit: real RIKEN/LLNL/Apptainer/SIF/GPU E2E has NOT run for this refactor. API mocks/fixtures are not described as E2E.

## Historical changes (v0.5.2 and earlier)

# Changelog

## 0.5.2.dev0 — make per-attempt evidence names single-writer and race-safe

- Fix the RIKEN real-machine `FileExistsError` caused by probing Common Base pip twice into the same immutable `base-pip-version.*` evidence stem.
- Probe Common Base `python -m pip --version` exactly once during tool preflight and carry that observed package-manager record forward into environment construction.
- Reject any reused command-evidence stem *before* launching a second command, so duplicate probe names cannot overwrite stdout/stderr and fail later in an unrelated atomic write.
- Add a static architecture rule that detects duplicate literal evidence stems across the preparation call graph.
- Make content-addressed concrete-plan publication create-or-verify so concurrent identical Ramble publishers do not fail a harmless TOCTOU race; conflicting content remains an error.
- No change to the agreed software boundary: only requirement text/setup scripts and declared artifacts are mounted; Python/pip/Bash come from the Common Base Container.

## 0.5.1.dev0 — align verification with Ramble repeat execution semantics

- Do not materialize Container execution plans for Ramble repeat-base experiments; Ramble uses them only for repeat aggregation and its ExecutePipeline intentionally skips them.
- `verify_upstream.py` filters repeat-base plans defensively when validating workspaces produced by the pinned Ramble semantics.
- Added regression tests for repeat-base vs repeat-child planning and singleton behavior.
- No change to the agreed software boundary: requirements/setup scripts are mounted; Python/pip/package management remain inside the Common Base Container.

## 0.5.0.dev0 — enforce the agreed container-native software boundary

- Python dependency input is requirement/lock/constraint text only; local wheel/sdist/VCS/direct-reference payload staging is removed.
- All Python installation uses the selected Common Base's declared `python -m pip` inside the container. No injected pip/Python/resolver/venv bootstrap.
- Removed host-native `NativeRuntime`/`native_case` environment-construction tests and the native-torch helper.
- Removed `--no-deps` and other Extension-owned resolver semantics. Requirements are interpreted by the selected Base pip; `/bpce/python` is only the writable destination.
- Command/tool installation remains Git-managed setup scripts executed by the Common Base Bash inside the container.
- `pip check` no longer parses version-specific diagnostic prose; before/after raw diagnostics from the same Base pip are compared.
- Architecture audit now guards the mount/package-manager boundary and rejects reintroduction of host-native builders or package payloads.

## 0.4.1.dev0 — explicit additional-lock installation

- Follow-up finding from the user's real test: 0.4.0 still depended on pip-version-specific transitive resolution during `--prefix` installation.
- Bump dependency policy to `base-pip-explicit-lock-prefix-v2`; existing initialized plans are not silently reinterpreted.
- Use the Common Base's pip with `--no-deps --prefix`; requirements/lock is the explicit closure of packages to add.
- Base-provided transitive dependencies are reused without asking pip to resolve/re-fetch them. Missing/incompatible dependencies are detected by the same Base pip's post-install delta check.
- Remove generated all-Base constraints from the construction path; add architecture guard and regression assertions for `--no-deps` / no `--constraint`.
- Keep the original v0.3.5 audit documents sealed; record this as a follow-up portability finding.

## 0.4.0.dev0 — architecture audit batch

Audit v0.3.5 before code changes; preserve 147-file input ledger and findings A01–A15.

- System schema2: explicit host runtime/worker and per-Base Python/Bash. No tool-name fallback in implementation.
- Production builder separated from runtime transport; Base pip constraints + native prefix reuses satisfied Base dependencies. No external installer/venv bootstrap.
- Explicit wheel-prefix policy and unsupported activation paths; checker failure separated from dependency delta; full probe evidence including timeout.
- Validate concrete mount paths; pin external input contents; include System provenance in condition identity.
- Freeze config/common/template at init (manifest3), not setup-time fallback.
- Source/Git provenance and symlink-aware output identity.
- Stronger exact trial/output/analysis verification and source-vs-installed mismatch checks.
- Replace principle-only torch test with actual production builder native test; arbitrary tool-path and Base-dependency tests.

This is a development release; actual Apptainer/GPU/RIKEN/LLNL E2E of this version must be run separately. Existing SIFs/experiments/results are not modified.

---


## 0.3.5.dev0

- Fixed the real-runtime `common-base-smoke` fixture to invoke the Common Base contract `python3`, not an optional `python` alias.
- Record `result.failure_phase = "benchmark"` whenever the benchmark process itself exits non-zero.
- No change to the v0.3.4 execution boundary: no injected pip/Python/package manager; Common Base native `python3 -m pip` remains authoritative.

- Fix real Apptainer base inspection on hosts where the runtime prints informational diagnostics to stderr (for example `gocryptfs not found`).
- Machine-readable container probes now keep stdout and stderr separate; JSON inspection parses only the Base command stdout.
- No architecture change: the Common Base still supplies Python/pip, and only experiment-owned inputs are mounted.


## 0.3.3.dev0

- Common BaseへExtension同梱pip/package managerを持ち込む方式を廃止。
- Python追加依存はCommon Base自身の `python -m pip` でattempt-private `/bpce/python`へ導入。
- Extension resource rootのContainer mountを廃止し、experiment input snapshotのみ `/bpce/inputs`へmount。
- command/tool導入用にgit管理 `setup_scripts` を追加し、`BPCE_PREFIX=/bpce/tools`へ構築。
- Base pipによる`pip check` before/after差分、run-local layer pin、Base shadow、smoke importを検査。
- Base pip version、setup command、layer inventory、dependency-check差分をCERへ記録。
- Spack既定、明示`+container`、Core generic hookは維持。

## 0.3.2.dev0

- 明示的+containerに統一し、legacy defaultによる自動有効化を廃止。
- Coreへの新たなhookを増やさず、再現性の自動・手動・CI validatorを外部へ追加。
- exact requirements、nested includes、local wheels、model/tokenizer identityを検査し入力snapshotと共通化。
- Base同名packageのversion差異をインストール前検出。暗黙torch必須を廃止、詳細family policyは追加しない。
- no-venv/ensurepipと固定tool、既存Ramble resource修正、run/attempt保存を維持。
- 実Baseが必要な検査は静的合格と区別。全hardwareでの保証はしない。

# Changelog

## 0.3.1.dev0

- Remove the production dependency on venv/ensurepip. Reuse the Common Base interpreter and installed packages; resolve against Base before installing selected pinned wheels to an attempt-private layer.
- Ship a checksum-verified pip 25.1.1 preparation tool without replacing Base pip. Keep upstream/vendor licenses and separate tool identity from benchmark package inventory.
- Add private layer activation for .pth, Base sitecustomize, console scripts, child Python and explicit Base interpreter selection. Runtime consumes an activation contract instead of a venv path.
- Add generic per-experiment extension_defaults with explicit +/- precedence; existing native experiments retain their previous defaults. Example container experiments can use the ordinary CLI without a container flag.
- Correct Ramble modifier repository layout/config name and use staged resource paths plus the application's concrete expander. Rebuild the portable helper.
- Preserve partial preparation records in CER and verify every newly created retry attempt, not only the increase in file count.
- Add implementation/review prompts, engineering review, current test evidence, migration instructions and native real-PyTorch CPU validation.

This is a development release. Local tests do not replace validation on the user's SIF, Apptainer, real RIKEN/LLNL checkouts, GPU or distributed systems.
